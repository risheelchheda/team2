package com.ris.linkedhashmap;


import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LinkedHashMapCls {
	public static void main(String[] args) {
		LinkedHashMap<Integer,String> lhm=new LinkedHashMap<>();
		int[] arr1= {1,2,3,4,5};
		String[] arr2= {"a","b","c","d","e"};
		for(int i=0;i<5;i++) {
			lhm.put(arr1[i],arr2[i]);
		}
		System.out.println(lhm);
		
		Iterator iterator=lhm.entrySet().iterator();
		while(iterator.hasNext()) {
			Entry<Integer,String> ent=(Entry<Integer,String>)iterator.next();
			System.out.println(ent.getKey()+"="+ent.getValue());
		}
	}
}
