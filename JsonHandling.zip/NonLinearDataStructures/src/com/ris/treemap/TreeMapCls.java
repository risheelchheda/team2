package com.ris.treemap;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

public class TreeMapCls {
	public static void main(String[] args) {
		TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
		int[] arr1 = { 4, 2, 8, 6, 1 };
		String[] arr2 = { "w", "t", "a", "b", "m" };
		for (int i = 0; i < 5; i++) {
			tm.put(arr1[i], arr2[i]);
		}
		System.out.println(tm);

		Iterator itr = tm.keySet().iterator();
		while (itr.hasNext()) {
			Object key = itr.next();
			System.out.println(key + "=" + tm.get(key));
		}
		Iterator itr1 = tm.entrySet().iterator();
		while (itr1.hasNext()) {
			Entry<Integer, String> ent =(Entry<Integer, String>)itr1.next();
			System.out.println(ent.getKey()+"="+ent.getValue());
		}
	}
}
