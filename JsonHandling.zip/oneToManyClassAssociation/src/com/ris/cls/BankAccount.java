package com.ris.cls;

public class BankAccount {
	
	private String accId;
	private String accType;
	
	public BankAccount(String id,String type) {
		// TODO Auto-generated constructor stub
		this.accId=id;
		this.accType=type;
	}
	
	public String toString() {
		return this.accId+" "+this.accType;
	}
	
	

}
