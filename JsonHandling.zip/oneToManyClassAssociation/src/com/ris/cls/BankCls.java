package com.ris.cls;

import java.util.Arrays;

public class BankCls {
	
	private String bankId;
	private String bankName;
	private BankAccount[] bActs;
	
	public BankCls(String id,String name,BankAccount[] accounts) {
		this.bankId=id;
		this.bankName=name;
		this.bActs=accounts;
		System.out.println(this.bankId+" "+this.bankName);
		System.out.println(Arrays.deepToString(bActs));
	}

	

}
