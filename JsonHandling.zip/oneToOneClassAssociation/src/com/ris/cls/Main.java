package com.ris.cls;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student[] sArr=new Student[3];
		Subject[] subArr=new Subject[3];
		
		int arr1[]= {11,12,13,14,15};
		String arr2[]= {"Phy","Geo","Botany","Zoology","Math"};
		String arr3[]= {"Jagan","Jeevan","Mrunal","Micheal"};
		
		for(int i=0;i<3;i++) {
			Subject sub=new Subject();
			sub.setSubid(arr1[i]);
			sub.setSubName(arr2[i]);
			Student std=new Student();
			std.setsId(i);
			std.setsName(arr3[i]);
			std.setSub(sub);
			sArr[i]=std;			
		}
		for(Student s:sArr) {
			System.out.println(s);
		}
		

	}

}
