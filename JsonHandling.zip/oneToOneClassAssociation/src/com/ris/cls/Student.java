package com.ris.cls;

public class Student {
	
	private int sId;
	private String sName;
	private Subject sub;
	
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public Subject getSub() {
		return sub;
	}
	public void setSub(Subject sub) {
		this.sub = sub;
	}
	
	public String toString(){
		return "Student id:"+this.sId+" "+"Student Name:"+this.sName+" "+"Subject Id"+this.sub.getSubid()+" "+"Subject Name:"+this.sub.getSubName();
	}
	

}
