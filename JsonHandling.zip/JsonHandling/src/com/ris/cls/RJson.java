package com.ris.cls;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;

public class RJson {
	
	static Connection con=null;
	static {
		try {
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDBA","postgres","root");
					
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	private List<Register> retList(){
		List<Register> rl=new ArrayList<Register>();

		try {
			String query="select * from public.\"register\"";
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				rl.add(new Register(rs.getInt(1),rs.getString(2),rs.getString(3)));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rl;
	}
	
	public String retJson() {
		String jsn="";
		ObjectMapper om=new ObjectMapper();
		try {
			jsn=om.writeValueAsString(retList());
		} catch (IOException e) {
		}
		return jsn;
	}
}
