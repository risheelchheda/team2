package com.ris.cls;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainCls {
	public static void main(String[] args) {
		RJson rj=new RJson();
		try {
			FileOutputStream fos=new FileOutputStream(new File("C:\\Users\\localadmin\\Desktop\\JavaTraining\\NPCIFolder\\regs.json"));
			String op=rj.retJson();
			fos.write(op.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
