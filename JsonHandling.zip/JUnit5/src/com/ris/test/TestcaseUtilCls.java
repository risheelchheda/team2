package com.ris.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ris.cls.UtilCls;

class TestcaseUtilCls {
	
	UtilCls cls=null;
	
	

	@BeforeEach
	void setUp() throws Exception {
		cls=new UtilCls();

	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	void testRetSub() {
		String uString="Ris";
		assertEquals(uString,cls.retSub("Risheel"));
	}

}
