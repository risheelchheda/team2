package com.ris.test;

import java.util.Comparator;
import java.util.List;

import com.ris.dao.EmployeeImpl;
import com.ris.mod.Employee;

public class MainCls {
	public static void main(String[] args) {
		EmployeeImpl emp=new EmployeeImpl();
		List<Employee> employees=emp.retEmp();
		for(Employee e:employees) {
			System.out.println(e);
		}
		System.out.println("*************************************************************************");
		System.out.println(emp.retEmp(2));
		System.out.println("*************************************************************************");
		System.out.println(emp.insEmp(new Employee(11,"John Doe",800000,"It")));
		List<Employee> employees1=emp.retEmp();
		for(Employee e:employees1) {
			System.out.println(e);
		}
		System.out.println("*************************************************************************");
		System.out.println(emp.upEmp(new Employee(11,"Risheel",600000,"Get")));
		List<Employee> employees2=emp.retEmp();
		for(Employee e:employees2) {
			System.out.println(e);
		}
		System.out.println("*************************************************************************");
		System.out.println(emp.delEmp(11));
		List<Employee> employees3=emp.retEmp();
		for(Employee e:employees3) {
			System.out.println(e);
		}
		System.out.println("*************************************************************************");
		System.out.println("Before Sorting");
		for(Employee e:employees) {
			System.out.println(e);
		}
		
		employees.sort(new Comparator<Employee>() {
			public int compare(Employee o1,Employee o2) {
				return (int) (o1.getSalary()-o2.getSalary());
			}
		});
		System.out.println("*************************************************************************");
		System.out.println("After Sorting");
		for(Employee e:employees) {
			System.out.println(e);
		}

	}
}
