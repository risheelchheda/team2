package com.ris.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ris.inte.IEmployee;
import com.ris.mod.Employee;

public class EmployeeImpl implements IEmployee {
	
	private static Connection con=null;
	private static Properties props=null;
	
	static {
		try {
			FileReader reader=new FileReader(new File("C:\\Users\\localadmin\\eclipse-workspace\\JdbcPractice\\src\\app.properties"));
			props=new Properties();
			props.load(reader);
			Class.forName(props.getProperty("drivername"));
			con=DriverManager.getConnection(props.getProperty("con"),props.getProperty("username"),props.getProperty("password"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Employee> retEmp() {
		List<Employee> employees=new ArrayList<>();
		try {
			String query="select * from public.\"Employee\"";
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Employee e=new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getString(4));
				employees.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return employees;
	}

	@Override
	public Employee retEmp(int id) {
		Employee e=null;
		try {
			String query="select * from public.\"Employee\" where empid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				e=new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getString(4));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return e;
	}

	@Override
	public String insEmp(Employee e) {
		String status="None";
		try {
			String query="insert into public.\"Employee\" values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, e.getEmpId());
			ps.setString(2, e.getName());
			ps.setDouble(3, e.getSalary());
			ps.setString(4,e.getDept());
			ps.executeUpdate();
			status="Done";
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return status;
	}

	@Override
	public String upEmp(Employee e) {
		String status="None";
		try {
			String query="update public.\"Employee\" set name=?,salary=?,dept=? where empid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1,e.getName());
			ps.setDouble(2, e.getSalary());
			ps.setString(3,e.getDept());
			ps.setInt(4, e.getEmpId());
			ps.executeUpdate();
			status="Done";
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return status;
	}

	@Override
	public String delEmp(int id) {
		String status="None";
		try {
			String query="delete from public.\"Employee\" where empid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, id);
			ps.executeUpdate();
			status="Done";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

}
