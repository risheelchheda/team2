package com.ris.inte;

import java.util.List;

import com.ris.mod.Employee;

public interface IEmployee {
	
	public List<Employee> retEmp();
	public Employee retEmp(int id);
	public String insEmp(Employee e);
	public String upEmp(Employee e );
	public String delEmp(int id);

}
