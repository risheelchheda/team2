package com.ris.inte;

import java.util.List;

import com.ris.mod.Register;

public interface IRegisterDao {

	public List<Register> retRegs();
	public Register retRegs(int id);
	public String insReg(Register r);
	public String upReg(Register r);
	public String delReg(int id);
	
}
