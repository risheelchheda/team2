package com.ris.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ris.inte.IRegisterDao;
import com.ris.mod.Register;

public class RegisterDaoImpl implements IRegisterDao {
	
	static Properties props=null;
	static Connection conn=null;
	
	static {
		try {
			FileReader reader=new FileReader(new File("C:\\Users\\localadmin\\eclipse-workspace\\Jdbc\\src\\app.properties"));
			Properties props=new Properties();
			props.load(reader);
			Class.forName(props.getProperty("drivername"));
			conn=DriverManager.getConnection(props.getProperty("conn"),props.getProperty("username"),props.getProperty("password"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Register> retRegs() {
		List<Register> lr=new ArrayList<>();
		try {
			String query="select * from public.\"register\"";
			PreparedStatement ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Register r=new Register(rs.getInt(1),rs.getString(2),rs.getString(3));
				lr.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lr;
	}

	@Override
	public Register retRegs(int id) {
		try {
			String query="select * from public.\"register\" where rid=?";
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			Register r=null;
			while(rs.next()) {
				r=new Register(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
			return  r;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String insReg(Register r) {
		try {
			String status="None";
			String query="insert into public.\"register\" values(?,?,?)";
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, r.getRid());
			ps.setString(2, r.getRname());
			ps.setString(3, r.getRemail());
			ps.executeUpdate();
			status="Done";
			return status;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String upReg(Register r) {
		try {
			String status="None";
			String query="update public.\"register\" set rname=?,remail=? where rid=?";
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, r.getRname());
			ps.setString(2, r.getRemail());
			ps.setInt(3, r.getRid());
			ps.executeUpdate();
			status="Done";
			return status;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String delReg(int id) {
		try {
			String query="Delete from public.\"register\" where rid=?";
			String status="None";
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, id);
			ps.executeUpdate();
			status="Done";
			return status;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
