package com.ris.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import com.ris.dao.RegisterDaoImpl;
import com.ris.mod.Register;

public class TesterMain {
	public static void main(String[] args) {
		RegisterDaoImpl impl=new RegisterDaoImpl();
		List<Register> lr=impl.retRegs();
		for(Register r:lr) {
			System.out.println(r);
		}
		
		System.out.println(impl.retRegs(3));
		Register r=new Register(12,"z","b@gmail");
		System.out.println(impl.insReg(r));
		Register r1=new Register(11,"c","c@gmail");
		System.out.println(impl.upReg(r1));
		System.out.println(impl.delReg(11));
		
		methAA();

		
	}

	private static void methAA() {
		try {
			FileReader reader=new FileReader(new File("C:\\Users\\localadmin\\eclipse-workspace\\Jdbc\\src\\app.properties"));
			Properties props=new Properties();
			props.load(reader);
			System.out.println(props.getProperty("drivername"));
			System.out.println(props.getProperty("con"));

			System.out.println(props.getProperty("username"));

			System.out.println(props.getProperty("passsword"));
			System.out.println(props.getProperty("tabname"));
			System.out.println(props.getProperty("tabaname"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
