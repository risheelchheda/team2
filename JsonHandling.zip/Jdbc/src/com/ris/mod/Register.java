package com.ris.mod;

public class Register {

	private int rid;
	private String rname;
	private String remail;
	public Register() {
	}
	public Register(int rid,String rname,String remail) {
		this.rid=rid;
		this.rname=rname;
		this.remail=remail;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRemail() {
		return remail;
	}
	public void setRemail(String remail) {
		this.remail = remail;
	}
	public String toString() {
		return this.rid+" "+this.rname+" "+this.remail;
	}
}
