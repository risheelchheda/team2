package com.ris.cls;
/**
 * String Utils class contains basic string operations
 */


public class StrUtilsCls {
/**
 * Method to convert string to upper case
 * @param String to be converted to upper case
 * @return Converted String
 */
	@Deprecated
	public String retUp(String a) {
		return a.toUpperCase();
	}
	/**
	 * Method to convert string to lower case
	 * @param String to be converted to lower case
	 * @return Converted String
	 */
	
	public String retLow(String a) {
		return a.toLowerCase();
		}
	
	/**
	 * Method to reverse a string
	 * @param String to be reversed
	 * @return Reversed String
	 */
	public String retRev(String a) {
		return (new StringBuffer(a).reverse().toString());
	}
}
