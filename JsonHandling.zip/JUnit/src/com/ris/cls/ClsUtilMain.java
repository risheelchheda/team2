package com.ris.cls;

public class ClsUtilMain {

	public String retAltUp(String u) {
		String finString="";
		char[] arr=u.toCharArray();
		int i=0;
		for(char c:arr) {
			if(i%2==0) {
				finString+=String.valueOf(c).toUpperCase();
			}
			else {
				finString+=String.valueOf(c).toLowerCase();
			}
			i+=1;
		}
		return finString;
	}

}
