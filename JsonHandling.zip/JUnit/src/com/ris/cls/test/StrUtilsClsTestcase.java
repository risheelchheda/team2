package com.ris.cls.test;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ris.cls.StrUtilsCls;

public class StrUtilsClsTestcase {
	StrUtilsCls cls=null;

	@Before
	public void setUp() throws Exception {
		cls=new StrUtilsCls();
	}

	@After
	public void tearDown() throws Exception {
		cls=null;
	}

	@Test
	public void testRetUp() {
		String yString="RISHEEL";
		assertEquals(yString,cls.retUp("Risheel") );
	}

//	@Ignore
	@Test
	public void testRetLow() {
		String yString="risheel";
		assertEquals(yString, cls.retLow("Risheel"));
	}

	@Test
	public void testRetRev() {
		String yString="leehsiR";
		assertEquals(yString,cls.retRev("Risheel"));
	}

}
