package com.team2.dao;

import java.security.PublicKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.team2.inte.IPayroll;
import com.team2.mod.Payroll;





/**
 * The {@code PayrollImpl} class implements the {@link IPayroll} interface and
 * provides the actual implementation of the methods for interacting with the payroll
 * data in the database. This includes operations such as retrieving payroll details,
 * inserting new payroll records, updating existing payrolls, and deleting payroll records.
 * The class uses JDBC to perform SQL queries against a PostgreSQL database.
 * @author Risheel
 **/

public class PayrollImpl implements IPayroll {
	static 	Connection con=null;

	static {
		try {
			Properties props= new Properties();
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Team2","postgres","root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	 /**
     * Retrieves a list of all payroll records from the database.
     * 
     * @return A list of {@link Payroll} objects containing all payroll records.
     */
    @Override
    public List<Payroll> retPayrolls() {
        List<Payroll> pList = new ArrayList<Payroll>();
        try {
            String query = "select * from public.\"Payroll\"";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Payroll payroll = new Payroll(rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
                        rs.getInt(6));
                pList.add(payroll);
                payroll.setPayId(rs.getInt(1));
                payroll.setLwp(rs.getInt(7));
                payroll.setGrossEarning(rs.getDouble(8));;
                payroll.setDeduction(rs.getDouble(9));
                payroll.setNetSalary(rs.getDouble(10));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pList;
    }

    /**
     * Retrieves a specific payroll record based on the provided payroll ID.
     * 
     * @param pid The payroll ID.
     * @return A {@link Payroll} object containing the payroll record with the specified ID.
     */
    @Override
    public Payroll retPayroll(int pid) {
        Payroll payroll = new Payroll();

        try {
            String query = "select * from public.\"Payroll\" where payid=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                payroll.setPayId(rs.getInt(1));
                payroll.setEmpId(rs.getInt(2));
                payroll.setPayMonth(rs.getInt(3));
                payroll.setPayYear(rs.getInt(4));
                payroll.setWorkingDays(rs.getInt(5));
                payroll.setDaysWorked(rs.getInt(6));
                payroll.setLwp(rs.getInt(7));
                payroll.setGrossEarning(rs.getDouble(8));
                payroll.setDeduction(rs.getDouble(9));
                payroll.setNetSalary(rs.getDouble(10));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return payroll;
    }

    /**
     * Retrieves the net salary for an employee based on their employee ID, pay month, and pay year.
     * 
     * @param empId The employee ID.
     * @param payMonth The month of the payroll.
     * @param payYear The year of the payroll.
     * @return The net salary of the employee for the given pay month and year.
     */
    @Override
    public double getSalary(int empId, int payMonth, int payYear) {
        double salary = 0;
        try {
            String query = "select netsalary from public.\"Payroll\" where empid=? and paymonth=? and payyear=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, empId);
            ps.setInt(2, payMonth);
            ps.setInt(3, payYear);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                salary = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return salary;
    }
    /**
     * Retrieves the gross earnings for an employee from the SalaryStructure table.
     * 
     * @param empid The employee ID.
     * @return The gross earnings of the employee.
     */

    
    public double retGrossEarning(int empid) {
    	double grossEarning=0;
		try {
			String query="Select * from public.\"SalaryStructure\" where empid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, empid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				grossEarning=rs.getDouble(2)+rs.getDouble(3)+rs.getDouble(4)+rs.getDouble(5)+rs.getDouble(6);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return grossEarning;
    	
    }
    /**
     * Retrieves the total perks for an employee.
     * 
     * @param empid The employee ID.
     * @return The total perks amount for the employee.
     */
    
	public double retPerks(int empid) {
		double perks=0;
		try {
			String query="select"
					+ "    p.medicalInsurance, "
					+ "    p.travelReimburse, "
					+ "    p.FitnessAllowances, "
					+ "    p.MobileReimburse, "
					+ "    p.certificationReimburse "
					+ "from"
					+ "   public.\"Employee\" e "
					+ "join"
					+ "  public.\"Perks\" p ON e.empGrade = p.grade "
					+ "where"
					+ "    e.empId = ?;";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, empid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				perks=rs.getDouble(1)+rs.getDouble(2)+rs.getDouble(3)+rs.getDouble(4)+rs.getDouble(5);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return perks;
	}

	/**
     * Retrieves the deductions for an employee based on their leave without pay (LWP) and gross earnings.
     * 
     * @param empid The employee ID.
     * @param lwp The number of leave without pay (LWP) days.
     * @param grossEarnings The total gross earnings of the employee.
     * @param workingDays The number of working days in the month.
     * @return The total deductions for the employee.
     */
    public double retDeductions(int empid,int lwp,double grossEarnings,int workingDays) {
    	double deductions=0;
		try {
			String query="Select pf,tax from public.\"SalaryStructure\" where empid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, empid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				deductions=rs.getDouble(1)+rs.getDouble(2);
			}
			deductions+=(grossEarnings/workingDays)*lwp;
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return deductions;
    }
    /**
     * Inserts a new payroll record into the database.
     * 
     * @param payroll The {@link Payroll} object containing the payroll data to be inserted.
     * @return A status message indicating whether the insertion was successful.
     */
    @Override
    public String insPayroll(Payroll payroll) {
        String status = "None";
        try {
            String query = "insert into public.\"Payroll\" (empid, paymonth, payyear, workingdays, daysworked, lwp, grossearning, deduction, netsalary) values (?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, payroll.getEmpId());
            ps.setInt(2, payroll.getPayMonth());
            ps.setInt(3, payroll.getPayYear());
            ps.setInt(4, payroll.getWorkingDays());
            ps.setInt(5, payroll.getDaysWorked());
            payroll.setLwp(payroll.getWorkingDays()-payroll.getDaysWorked());
            ps.setInt(6, payroll.getLwp());
            payroll.setGrossEarning(retGrossEarning(payroll.getEmpId())+retPerks(payroll.getEmpId()));
            ps.setDouble(7, payroll.getGrossEarning());
            payroll.setDeduction(retDeductions(payroll.getEmpId(), payroll.getLwp(), payroll.getGrossEarning(), payroll.getWorkingDays()));
            ps.setDouble(8, payroll.getDeduction());
            payroll.setNetSalary(payroll.getGrossEarning()-payroll.getDeduction());
            ps.setDouble(9, payroll.getNetSalary());
            ps.executeUpdate();
            status = "Done";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    /**
     * Updates an existing payroll record in the database.
     * 
     * @param payroll The {@link Payroll} object containing the updated payroll data.
     * @return A status message indicating whether the update was successful.
     */
    @Override
    public String upPayroll(Payroll payroll) {
        String status = "None";
        try {
            String query = "Update public.\"Payroll\" set empid=?, paymonth=?, payyear=?, workingdays=?, daysworked=?, lwp=?, grossearning=?, deduction=?, netsalary=? where payid=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, payroll.getEmpId());
            ps.setInt(2, payroll.getPayMonth());
            ps.setInt(3, payroll.getPayYear());
            ps.setInt(4, payroll.getWorkingDays());
            ps.setInt(5, payroll.getDaysWorked());
            payroll.setLwp(payroll.getWorkingDays()-payroll.getDaysWorked());
            ps.setInt(6, payroll.getLwp());
            payroll.setGrossEarning(retGrossEarning(payroll.getEmpId())+retPerks(payroll.getEmpId()));
            ps.setDouble(7, payroll.getGrossEarning());
            payroll.setDeduction(retDeductions(payroll.getEmpId(), payroll.getLwp(), payroll.getGrossEarning(), payroll.getWorkingDays()));
            ps.setDouble(8, payroll.getDeduction());
            payroll.setNetSalary(payroll.getGrossEarning()-payroll.getDeduction());
            ps.setDouble(9, payroll.getNetSalary());
            ps.setInt(10, payroll.getPayId());
            ps.executeUpdate();
            status = "Done";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    /**
     * Deletes a payroll record from the database based on the specified payroll ID.
     * 
     * @param pid The payroll ID of the record to delete.
     * @return A status message indicating whether the deletion was successful.
     */
    @Override
    public String delPayroll(int pid) {
        String status = "None";
        try {
            String query = "delete from public.\"Payroll\" where payid=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pid);
            ps.executeUpdate();
            status = "Done";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    /**
     * Retrieves all salary details for an employee, including salary, pay month, and pay year.
     * 
     * @param empid The employee ID.
     * @return A list of lists where each inner list contains the salary, pay month, and pay year for the employee.
     */
    @Override
    public List<List<Double>> getAllSalary(int empid) {
        List<List<Double>> empSalary = new ArrayList<List<Double>>();
        try {
            String query = "select netsalary,paymonth,payyear from public.\"Payroll\" where empid=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, empid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                List<Double> salary = new ArrayList<Double>();
                salary.add(rs.getDouble(1));
                salary.add(rs.getDouble(2));
                salary.add(rs.getDouble(3));
                empSalary.add(salary);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return empSalary;
    }

    /**
     * Retrieves the leave without pay (LWP) days for an employee for a specific month and year.
     * 
     * @param empid The employee ID.
     * @param payMonth The pay month.
     * @param payYear The pay year.
     * @return The number of LWP days for the employee in the specified month and year.
     */
    @Override
    public int getLWP(int empid, int payMonth, int payYear) {
        int lwp = 0;
        try {
            String query = "select lwp from public.\"Payroll\" where empid=? and paymonth=? and payyear=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, empid);
            ps.setInt(2, payMonth);
            ps.setInt(3, payYear);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lwp = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lwp;
    }
}