package com.sms.models;

public class Employee {
	private int empId;
    private String empName;
    private String empEmail;
    private String empPhone;
    private String empAddress;
    private String empDepartment;
    private String empDesignation;
    private String empGrade; // Foreign key to Perks table

    
//    Getters & Setters
    public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpPhone() {
		return empPhone;
	}
	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

//	Constructors
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int empId, String empName, String empEmail, String empPhone, String empAddress,
			String empDepartment, String empDesignation, String empGrade) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
		this.empPhone = empPhone;
		this.empAddress = empAddress;
		this.empDepartment = empDepartment;
		this.empDesignation = empDesignation;
		this.empGrade = empGrade;
	}
	
//	toString
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

        sb.append("====================================================================\n");
        sb.append("                         Employee Details                           \n");
        sb.append("====================================================================\n");
        sb.append(String.format("-> Employee Id        : %d%n", empId));
        sb.append(String.format("-> Name               : %s%n", empName));
        sb.append(String.format("-> Email              : %s%n", empEmail));
        sb.append(String.format("-> Phone Number       : %s%n", empPhone));
        sb.append(String.format("-> Address            : %s%n", empAddress));
        sb.append(String.format("-> Department         : %s%n", empDepartment));
        sb.append(String.format("-> Designation        : %s%n", empDesignation));
        sb.append(String.format("-> Grade              : %s%n", empGrade));
        sb.append("====================================================================\n");

        // Return the constructed string
        return sb.toString();
        }
    
	
    
}
