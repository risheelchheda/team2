package com.sms.models;

public class Payroll {

	private int payId;
	private int empId; // Foreign key to Employee table
	private int payMonth;
	private int payYear;
	private int workingDays;
	private int daysWorked;
	private int lwp; // Leave without pay
	private double grossEarning;
	private double deduction;
	private double netSalary;

//	Getters & Setters
	public int getPayId() {
		return payId;
	}
	public void setPayId(int payId) {
		this.payId = payId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getPayMonth() {
		return payMonth;
	}
	public void setPayMonth(int payMonth) {
		this.payMonth = payMonth;
	}
	public int getPayYear() {
		return payYear;
	}
	public void setPayYear(int payYear) {
		this.payYear = payYear;
	}
	public int getWorkingDays() {
		return workingDays;
	}
	public void setWorkingDays(int workingDays) {
		this.workingDays = workingDays;
	}
	public int getDaysWorked() {
		return daysWorked;
	}
	public void setDaysWorked(int daysWorked) {
		this.daysWorked = daysWorked;
	}
	public int getLwp() {
		return lwp;
	}
	public void setLwp(int lwp) {
		this.lwp = lwp;
	}
	public double getGrossEarning() {
		return grossEarning;
	}
	public void setGrossEarning(double grossEarning) {
		this.grossEarning = grossEarning;
	}
	public double getDeduction() {
		return deduction;
	}
	public void setDeduction(double deduction) {
		this.deduction = deduction;
	}
	public double getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

//Constructors
	public Payroll() {
		// TODO Auto-generated constructor stub
	}	
	
	public Payroll(int payId, int empId, int payMonth, int payYear, int workingDays, int daysWorked, int lwp,
			double grossEarning, double deduction, double netSalary) {
		super();
		this.payId = payId;
		this.empId = empId;
		this.payMonth = payMonth;
		this.payYear = payYear;
		this.workingDays = workingDays;
		this.daysWorked = daysWorked;
		this.lwp = lwp;
		this.grossEarning = grossEarning;
		this.deduction = deduction;
		this.netSalary = netSalary;
	}
//toString Method
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

        sb.append("====================================================================\n");
        sb.append("                              Payroll Details                       \n");
        sb.append("====================================================================\n");
        sb.append(String.format("| %-32s | %28d |\n", "Pay ID", payId));
        sb.append(String.format("| %-32s | %28d |\n", "Employee ID", empId));
        sb.append(String.format("| %-32s | %28s |\n", "Pay Month", payMonth));
        sb.append(String.format("| %-32s | %28d |\n", "Pay Year", payYear));
        sb.append(String.format("| %-32s | %28d |\n", "Working Days", workingDays));
        sb.append(String.format("| %-32s | %28d |\n", "Days Worked", daysWorked));
        sb.append(String.format("| %-32s | %28d |\n", "Leave Without Pay (LWP)", lwp));
        sb.append(String.format("| %-32s | %28.2f |\n", "Gross Earnings", grossEarning));
        sb.append(String.format("| %-32s | %28.2f |\n", "Deduction", deduction));
        sb.append(String.format("| %-32s | %28.2f |\n", "Net Salary", netSalary));
        sb.append("====================================================================\n");
        
        return sb.toString();
	}


}
