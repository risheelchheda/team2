package com.sms.main;

import java.util.Scanner;

import com.sms.dao.EmployeeDaoImpl;
import com.sms.dao.PayrollDaoImpl;
import com.sms.dao.PerksDaoImpl;
import com.sms.dao.SalaryStructureImpl;
import com.sms.models.Employee;
import com.sms.models.Payroll;
import com.sms.models.Perks;
import com.sms.models.SalaryStructure;

public class SMS_Employee {
	
	private EmployeeDaoImpl employeeDaoImpl=new EmployeeDaoImpl();
	private SalaryStructureImpl salaryStructureImpl = new SalaryStructureImpl();
	private PerksDaoImpl perksDaoImpl = new PerksDaoImpl();
	private PayrollDaoImpl payrollDaoImpl = new PayrollDaoImpl();
	private int empId=0;
	private Scanner sc = new Scanner(System.in);
	
	public void getEmployeeLogin() {
		
		String phoneString;
		
		boolean valid =false;
		while(!valid){
			System.out.println("Enter your Employee Id");
			if(sc.hasNextInt())
			{
				empId=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter Valid Employee id");
				sc.nextLine();
			}
			
		}
		sc.nextLine();
		System.out.println("Enter your phone number");
		phoneString = sc.nextLine();
		
		if(employeeDaoImpl.getEmpPhone(empId).equals(phoneString))
			getEmployeeMenu();
		else {
			System.out.println("Wrong Employee Id/Phone Number (Press Enter to Continue)");
			sc.nextLine();
			SalaryManagementSystem.main(null);
		}
		
		sc.close();
		
	}
	
	
	public void getEmployeeMenu() {
		System.out.println("====================================================================");
		System.out.println("                    WELCOME TO EMPLOYEE PORTAL                      ");
		System.out.println("====================================================================");
		System.out.println("1.Personal Details \n2.Salary Structure\n3.My Perks\n4.My Payroll\n5.Logout");
		System.out.print("Enter Your Choice : ");
		int ch = sc.nextInt();
		sc.nextLine();
		
		switch (ch) {
		case 1:
			getPersonalDetails();
			break;
		case 2:
			getSalaryStructure();
			break;
		case 3:
			getPerks();
			break;
		case 4:
			getPayroll();
			break;
		case 5:
			System.out.println("Press Enter to Logout");
			sc.nextLine();
			SalaryManagementSystem.main(null);
			break;
		default:
			break;
		}
		
		sc.close();
	}
	
	public void getPersonalDetails() {
		Employee employee = employeeDaoImpl.getEmployee(empId);
		System.out.println(employee);
		
		System.out.println("Press Enter to go back to Employee Menu");
		sc.nextLine();
		getEmployeeMenu();
		
	}
	
	public void getSalaryStructure() {
		SalaryStructure salaryStructure = salaryStructureImpl.getSalaryStructure(empId);
		
		if(salaryStructure==null)
			System.out.println("No salary structure define for you");
		else {
			System.out.println(salaryStructure);
		}
		
		System.out.println("Press Enter to go back to Employee Menu");
		sc.nextLine();
		getEmployeeMenu();
	}
	public void getPerks() {
		Perks perk = perksDaoImpl.getPerk(employeeDaoImpl.getEmpGrade(empId));
		System.out.println(perk);
		
		System.out.println("Press Enter to go back to Employee Menu");
		sc.nextLine();
		getEmployeeMenu();
	}
	public void getPayroll() {

		boolean valid=false;
		int month=0;
		while (!valid) {
			System.out.println("Enter month to get Payroll");
			if(sc.hasNextInt())
			{
				
				month=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 1 to 12");
				sc.nextLine();
			}
		}
		sc.nextLine();
		valid=false;
		int year=0;
		while (!valid) {
			System.out.println("Enter Year to get Payroll");
			if(sc.hasNextInt())
			{
				
				year=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 2000 to 2099");
				sc.nextLine();
			}
		}
		sc.nextLine();
		Payroll payroll = payrollDaoImpl.getPayroll(empId, month, year);
		if(payroll==null) {
			System.out.println("No Payroll generated for "+ month+", "+ year);
		}
		else {
			System.out.println(payroll);
		}
		System.out.println("Press Enter to go back to Employee Menu");
		sc.nextLine();
		getEmployeeMenu();
	}
	
	

}
