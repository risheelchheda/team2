package com.sms.services;

import java.util.List;

import com.sms.models.Employee;

public interface IEmployeeDao {

	public List<Employee> getEmployees();
	public Employee getEmployee(int empId);
	public String addEmployee(Employee emp);
	public int updateEmployee(Employee emp);
	public int deleteEmploye(int empId);
	public String getEmpPhone(int empId);
	public String getEmpGrade(int empId);
	
}
