package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.sms.models.Payroll;
import com.sms.services.IPayrollDao;
import com.sms.utils.DbUtilClass;
import com.sms.utils.PropertyUtils;

/**
 * The {@code PayrollDaoImpl} class implements the {@link IPayrollDao} interface and
 * provides the actual implementation of the methods for interacting with the payroll
 * data in the database. This includes operations such as retrieving payroll details,
 * inserting new payroll records and updating existing payroll records.
 * The class uses JDBC to perform SQL queries against a PostgreSQL database.
 * 
 **/
public class PayrollDaoImpl implements IPayrollDao{

	private Connection connection = DbUtilClass.getDBConnection();
	private Properties props = PropertyUtils.getProperties();
	private String payrollString = props.getProperty("payroll");
	
	/**
	 * Retrieves a list of all payroll records of an employee from the database.
	 * 
	 * @param pid The payroll ID.
	 * 
	 * @return A list of {@link Payroll} object containing all payroll records of an employee
	 */
	@Override
	public List<Payroll> getPayrolls(int empId) {
		
		List<Payroll> payrollList = new ArrayList<Payroll>();
		
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+payrollString+"WHERE empId="+empId);
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return payrollList;
			while (resultSet.next()) {
				Payroll payroll = new Payroll(resultSet.getInt(1),resultSet.getInt(2),resultSet.getInt(3),resultSet.getInt(4),resultSet.getInt(5),resultSet.getInt(6),resultSet.getInt(7), resultSet.getDouble(8), resultSet.getDouble(9), resultSet.getDouble(10));
				payrollList.add(payroll);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return payrollList;
	}

	@Override
	public Payroll getPayroll(int empId, int month, int year) {
		
		Payroll payroll =null;
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+payrollString+" WHERE empId = "+empId+" AND payMonth = "+month+" AND payYear = "+year);
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return payroll;
			resultSet.next();
			payroll = new Payroll(resultSet.getInt(1),resultSet.getInt(2),resultSet.getInt(3),resultSet.getInt(4),resultSet.getInt(5),resultSet.getInt(6),resultSet.getInt(7), resultSet.getDouble(8), resultSet.getDouble(9), resultSet.getDouble(10));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return payroll;
	}

	@Override
	public int addPayroll(Payroll payroll) {
		
		int status= -1;
		
		try {
			PreparedStatement statement = connection.prepareStatement("INSERT INTO "+payrollString+" (empId, payMonth, payYear, workingDays, daysWorked, lwp, grossEarning, deduction, netSalary) VALUES (?,?,?,?,?,?,?,?,?)");
			statement.setInt(1, payroll.getEmpId());
			statement.setInt(2,payroll.getPayMonth());
			statement.setInt(3, payroll.getPayYear());
			statement.setInt(4, payroll.getWorkingDays());
			statement.setInt(5, payroll.getDaysWorked());
			statement.setInt(6, payroll.getLwp());
			statement.setDouble(7, payroll.getGrossEarning());
			statement.setDouble(8, payroll.getDeduction());
			statement.setDouble(9, payroll.getNetSalary());
			
			status=statement.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
	}

	@Override
	public int deletePayrolls(int empId) {
		int status=0;
		try {
			PreparedStatement statement = connection.prepareStatement("DELETE FROM "+payrollString+" WHERE empid=?");
			statement.setInt(1,empId);
			status = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	

}
