package com.sms.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.sms.dao.EmployeeDaoImpl;
import com.sms.dao.PerksDaoImpl;
import com.sms.main.SMS_Admin;
import com.sms.models.Employee;

public class EmployeeUtils {
	
	Scanner sc = new Scanner(System.in);
	EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
	PerksDaoImpl perksDaoImpl = new PerksDaoImpl();
	
	public boolean addEmployee() {
		
		System.out.print("Enter Employee Name : ");
		String empName = sc.nextLine();
		System.out.print("Enter Employee Email : ");
	    String empEmail= sc.nextLine();
	    System.out.print("Enter Employee Phone : ");
	    String empPhone = sc.nextLine();
	    System.out.print("Enter Employee Address : ");
	    String empAddress = sc.nextLine();
	    System.out.print("Enter Employee Department : ");
	    String empDepartment = sc.nextLine();
	    System.out.print("Enter Employee Designation : ");
	    String empDesignation = sc.nextLine();
	    
	    String empGrade="";
	    List<String> gradeList = perksDaoImpl.getGrades();
	    boolean flag=false;
	    while (flag==false) {
	    	System.out.print("Enter Employee Grade : ");
		    empGrade = sc.nextLine();
		    
		    if(gradeList.contains(empGrade))
		    	flag=true;
		    else {
				System.out.println("No such grade, Select from these( A1, A2, B1, B2, C1, C2)");
			}
			
		}
	    
	    
	    Employee employee = new Employee(0, empName, empEmail, empPhone, empAddress, empDepartment, empDesignation, empGrade);
	    
	    String status =employeeDaoImpl.addEmployee(employee);
	    

	    int elements = Integer.parseInt(status.substring(0,status.indexOf(':')));
	    int empId=Integer.parseInt(status.substring(status.indexOf(':')+1));
	    
	    if(elements>0){
		    SalaryStructureUtils salaryStructureUtils = new SalaryStructureUtils();
		    return salaryStructureUtils.addSalaryStructure(empId);
	    }
	    else {
			return false;
		}
	}

	public void getEmployees() {
		List<Employee> employeeList = employeeDaoImpl.getEmployees();
		if(employeeList==null)
			System.out.println("No employees in Database");
		else {
			Iterator<Employee> iterator = employeeList.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}
		
		
	}

	public void getEmployee() {
		int empId=0;
		boolean valid=false;
		while (!valid) {
			System.out.print("Enter Employee Id to search ");
			if(sc.hasNextInt())
			{
				empId=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter Valid Employee Id");
				sc.nextLine();
			}
		}
		sc.nextLine();
		Employee employee = employeeDaoImpl.getEmployee(empId);
		if(employee==null)
			System.out.println("No Employee with given employee Id");
		else {
			System.out.println(employee);
		}
		
		
	}

	public boolean updateEmployee() {
		
		int empId=-1;
		Employee emp = null;
		
		while(emp==null)
		{
			boolean valid=false;
			while (!valid) {
				System.out.print("Enter Employee Id to update ");
				if(sc.hasNextInt())
				{
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}
			
			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
			{
				System.out.println("No employee found with given employee Id");
				System.out.println("Taking you back to Employee Menu");
				System.out.println("Press Enter to Continue");
				sc.nextLine();
				(new SMS_Admin()).getAdminEmployeeMenu();
		
			}
				
		}
		sc.nextLine();
		System.out.print("Enter Employee Name : ");
		String empName = sc.nextLine();
		System.out.print("Enter Employee Email : ");
	    String empEmail= sc.nextLine();
	    System.out.print("Enter Employee Phone : ");
	    String empPhone = sc.nextLine();
	    System.out.print("Enter Employee Address : ");
	    String empAddress = sc.nextLine();
	    System.out.print("Enter Employee Department : ");
	    String empDepartment = sc.nextLine();
	    System.out.print("Enter Employee Designation : ");
	    String empDesignation = sc.nextLine();
	    String empGrade="";
	    List<String> gradeList = perksDaoImpl.getGrades();
	    boolean flag=false;
	    while (flag==false) {
	    	System.out.print("Enter Employee Grade : ");
		    empGrade = sc.nextLine();
		    
		    if(gradeList.contains(empGrade))
		    	flag=true;
		    else {
				System.out.println("No such grade, Select from these( A1, A2, B1, B2, C1, C2)");
			}
			
		}
		
	    Employee employee = new Employee(empId, empName, empEmail, empPhone, empAddress, empDepartment, empDesignation, empGrade);
	    
	    if (employeeDaoImpl.updateEmployee(employee)>0)
	    	return true;
	    return false;
	}

	
	public boolean deleteEmployee() {
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			boolean valid=false;
			while (!valid) {
				System.out.print("Enter Employee Id to delete ");
				if(sc.hasNextInt())
				{
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}
			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
			{
				System.out.println("No employee found with given employee Id");
				System.out.println("Taking you back to Employee Menu");
				System.out.println("Press Enter to Continue");
				sc.nextLine();
				(new SMS_Admin()).getAdminEmployeeMenu();
		
			}
				
		}
		sc.nextLine();
		
		SalaryStructureUtils salaryStructureUtils = new SalaryStructureUtils();
		salaryStructureUtils.deleteSalaryStructure(empId);
		PayrollUtils payrollUtils = new PayrollUtils();
		payrollUtils.deletePayrolls(empId);
		if(employeeDaoImpl.deleteEmploye(empId)>0){
			return true;
		}
		return false;
	}

	
	
}
