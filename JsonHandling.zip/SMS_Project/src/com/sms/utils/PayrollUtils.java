package com.sms.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.sms.dao.EmployeeDaoImpl;
import com.sms.dao.PayrollDaoImpl;
import com.sms.dao.PerksDaoImpl;
import com.sms.dao.SalaryStructureImpl;
import com.sms.models.Employee;
import com.sms.models.Payroll;
import com.sms.models.SalaryStructure;

public class PayrollUtils {

	
	
	Scanner sc = new Scanner(System.in);
	EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
	SalaryStructureImpl salaryStructureImpl = new SalaryStructureImpl();
	PayrollDaoImpl payrollDaoImpl = new PayrollDaoImpl();
	
	
	public boolean addPayroll() {
		
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			System.out.print("Enter employee Id : ");
			boolean valid=false;
			while (!valid) {
				System.out.println("Enter employee Id to add Payroll");
				if(sc.hasNextInt())
				{
					
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}

			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
				System.out.println("No employee found with given employee Id");
		}
		sc.nextLine();
		
		boolean valid=false;
		int month=0;
		while (!valid) {
			System.out.println("Enter month to add Payroll");
			if(sc.hasNextInt())
			{
				
				month=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 1 to 12");
				sc.nextLine();
			}
		}
		sc.nextLine();
		valid=false;
		int year=0;
		while (!valid) {
			System.out.println("Enter Year to get Payroll");
			if(sc.hasNextInt())
			{
				
				year=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 2000 to 2099");
				sc.nextLine();
			}
		}
		sc.nextLine();
		valid=false;
		int workingDays=0;
		while (!valid) {
			System.out.println("Enter total working days");
			if(sc.hasNextInt())
			{
				
				workingDays=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter a valid number");
				sc.nextLine();
			}
		}
		sc.nextLine();
		valid=false;
		int daysWorked=0;
		while (!valid) {
			System.out.println("Enter total days worked by employee");
			if(sc.hasNextInt())
			{
				
				daysWorked=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter a valid number");
				sc.nextLine();
			}
		}
		sc.nextLine();
		if(month<1 || month>12 || year < 2000 || year>2099 || daysWorked>workingDays) {
			System.out.println("Wrong Input enter again");
			return addPayroll();
		}
		
		int lwp = workingDays-daysWorked;
		
		SalaryStructure salaryStructure = salaryStructureImpl.getSalaryStructure(empId);
		
		double grossEarning = salaryStructure.getBasic()+salaryStructure.getDA()+salaryStructure.getHRA()+salaryStructure.getPF()+salaryStructure.getTax();
		double deduction = ((grossEarning/workingDays)*lwp)+salaryStructure.getPF()+salaryStructure.getTax()+(new PerksDaoImpl()).getPerk(emp.getEmpGrade()).getMedicalInsurance() ;
		double netSalary = grossEarning-deduction;
		
		Payroll payroll = new Payroll(-1, empId, month, year, workingDays, daysWorked, lwp, grossEarning, deduction, netSalary);
		if(payrollDaoImpl.addPayroll(payroll)>0)
			return true;
		return false;
	}

	public void getPayrolls() {
		
		List<Payroll> payrolls = new ArrayList<Payroll>();
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			boolean valid=false;
			while (!valid) {
				System.out.println("Enter employee Id to get Payroll");
				if(sc.hasNextInt())
				{
					
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}
			
			sc.nextLine();
			emp = employeeDaoImpl.getEmployee(empId);
			
			if(emp==null)
				System.out.println("No employee found with given employee Id");
		}
		payrolls= payrollDaoImpl.getPayrolls(empId);
		
		if(payrolls==null)
			System.out.println("No Payroll found for given employee");
		else {
			Iterator<Payroll> iterator = payrolls.iterator();
			
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
				
			}
		}
		
	}

	public void getPayroll() {
		
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			boolean valid=false;
			while (!valid) {
				System.out.println("Enter employee Id to get Payroll");
				if(sc.hasNextInt())
				{
					
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}
			sc.nextLine();
			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
				System.out.println("No employee found with given employee Id");
		}
		boolean valid=false;
		int month=0;
		while (!valid) {
			System.out.println("Enter month to get Payroll");
			if(sc.hasNextInt())
			{
				
				month=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 1 to 12");
				sc.nextLine();
			}
		}
		sc.nextLine();
		valid=false;
		int year=0;
		while (!valid) {
			System.out.println("Enter Year to get Payroll");
			if(sc.hasNextInt())
			{
				
				year=sc.nextInt();
				valid=true;
			}
			else {
				System.out.println("Enter between 2000 to 2099");
				sc.nextLine();
			}
		}
		sc.nextLine();
		if(month<1 || month>12 || year<2000 || year>2099) {
			System.out.println("Month/Year Out of Range[Month(1-12), Year(2000-2099)]! Enter Again");
			getPayroll();
			return;
		}
		
		
		Payroll payroll = payrollDaoImpl.getPayroll(empId, month, year);
		if(payroll==null) {
			System.out.println("No Payroll generated for "+ month+", "+ year);
		}
		else {
			System.out.println(payroll);
		}
		
		
	}

	public int deletePayrolls(int empId) {
		return payrollDaoImpl.deletePayrolls(empId);
	}

}
