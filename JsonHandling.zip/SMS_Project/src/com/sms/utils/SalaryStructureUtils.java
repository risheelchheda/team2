package com.sms.utils;

import java.util.Scanner;

import com.sms.dao.EmployeeDaoImpl;
import com.sms.dao.SalaryStructureImpl;
import com.sms.main.SMS_Admin;
import com.sms.models.Employee;
import com.sms.models.SalaryStructure;

public class SalaryStructureUtils {
	
	Scanner sc = new Scanner(System.in);
	SalaryStructureImpl salaryStructureImpl = new SalaryStructureImpl();
	EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
	
	public boolean addSalaryStructure(int empId) {
		
		boolean valid=false;
		double basic=0;
		while (!valid) {
			System.out.print("Enter Basic Salary of Employee : ");
			if(sc.hasNextDouble())
			{
				basic=sc.nextDouble();
				valid=true;
			}
			else {
				System.out.println("Wrong Input Enter again");
				sc.nextLine();
			}
		}
			
	    sc.nextLine();
	    double hra = basic*0.50;
	    double da = basic*0.20;
	    double pf = basic*0.12;
	    double tax = getTax(basic);
	    
	    SalaryStructure salaryStructure = new SalaryStructure(empId, basic, hra, da, pf, tax);
	    
	    
	    if(salaryStructureImpl.addSalaryStructure(salaryStructure)>0) {
	    	return true;
	    }
	    else {
			return false;
		}
	}
	
	public int deleteSalaryStructure(int empId) {
		return salaryStructureImpl.deleteSalaryStructure(empId);
	}
	
	public boolean updateSalaryStructure() {
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			System.out.print("Enter employee Id : ");
			boolean valid=false;
			while (!valid) {
				System.out.println("Enter employee Id to add Payroll");
				if(sc.hasNextInt())
				{
					
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}

			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
				System.out.println("No employee found with given employee Id");
		}
		sc.nextLine();
		boolean valid=false;
		double basic=0;
		while (!valid) {
			System.out.print("Enter Basic Salary of Employee : ");
			if(sc.hasNextDouble())
			{
				basic=sc.nextDouble();
				valid=true;
			}
			else {
				System.out.println("Wrong Input Enter again");
				sc.nextLine();
			}
		}
	    sc.nextLine();
	    double hra = basic*0.50;
	    double da = basic*0.20;
	    double pf = basic*0.12;
	    double tax = getTax(basic);
	    
	    SalaryStructure salaryStructure = new SalaryStructure(empId, basic, hra, da, pf, tax);
	    
	    
	    if(salaryStructureImpl.updateSalaryStructure(salaryStructure)>0) {
	    	return true;
	    }
	    else {
			return false;
		}
	}
 	
	public void getSalaryStructure()
	{
		int empId=-1;
		Employee emp = null;
		while(emp==null)
		{
			System.out.print("Enter employee Id : ");
			boolean valid=false;
			while (!valid) {
				System.out.println("Enter employee Id to add Payroll");
				if(sc.hasNextInt())
				{
					
					empId=sc.nextInt();
					valid=true;
				}
				else {
					System.out.println("Enter Valid Employee Id");
					sc.nextLine();
				}
			}

			emp = employeeDaoImpl.getEmployee(empId);
			if(emp==null)
			{
				System.out.println("No employee found with given employee Id");
				System.out.println("Taking you back to Salary structure menu");
				(new SMS_Admin()).getAdminSalaryStructureMenu();
			}
				
		}
		sc.nextLine();
		
		SalaryStructure salaryStructure = salaryStructureImpl.getSalaryStructure(empId);
		if(salaryStructure==null) {
			System.out.println("No Salary Structure found for given emplyee! Want to Add(y/n)");
			String str = sc.nextLine();
			if(str.equalsIgnoreCase("Y")) {
				if(addSalaryStructure(empId))
					System.out.println("Successfully added salary structure for employee");
				else {
					System.out.println("Not able to add salary structure! Try again later");
				}
			}
		}
		else {
			System.out.println(salaryStructure);
		}
		
		
	}

	public static double getTax(double basic) {
		if(basic<10000) {
			return 0;
		}
		else if(basic<15000){
			return basic * 0.05;
		}
		else if(basic<20000){
			return basic*0.15;
		}
		else if (basic<25000) {
			return basic*0.20;
		}
		else if (basic<30000) {
			return basic*0.25;
		}
		else {
			return basic*0.35;
		}
	}

	
}
