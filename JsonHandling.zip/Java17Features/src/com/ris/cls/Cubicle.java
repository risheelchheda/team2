package com.ris.cls;

public class Cubicle {
	private int dim;
	public int getDim() {
		return dim;
	}
	public void setDim(int dim) {
		this.dim = dim;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name;
	public Cubicle() {
	}
	public Cubicle(int a,String b) {
		this.dim=a;
		this.name=b;
	}
	@Override
	public String toString() {
		return "Cubicle [dim=" + dim + ", name=" + name + "]";
	}
	
}


