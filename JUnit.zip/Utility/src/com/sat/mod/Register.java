package com.sat.mod;


/**
 * Pojo class 
 * @author Risheel
 */

public class Register {
	private int rid;
	private String rname;
	private String remail;
	public Register() {
		// TODO Auto-generated constructor stub
	}
	public Register(int rid,String rname,String remail) {
		// TODO Auto-generated constructor stub
		this.rid=rid;
		this.rname=rname;
		this.remail=remail;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRemail() {
		return remail;
	}
	public void setRemail(String remail) {
		this.remail = remail;
	}
	
	public String toString() {
		return this.rid+" "+this.rname+" "+this.remail;
	}
	
	
	
}
