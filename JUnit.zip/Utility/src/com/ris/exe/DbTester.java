package com.ris.exe;

import java.util.Iterator;
import java.util.List;

import com.ris.ut.DbUtilsCls;
import com.sat.mod.Register;


public class DbTester {
	public static void main(String[] args) {
		DbUtilsCls db=new DbUtilsCls();
		List<Register> lr=db.retRegs();
		Iterator itr=lr.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
