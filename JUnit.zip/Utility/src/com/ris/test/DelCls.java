package com.ris.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DelCls {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the id you want to delete");
		int id=scan.nextInt();
		Class.forName("org.postgresql.Driver");
		Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDBA","postgres","root");
		String query="Delete from public.\"register\"where rid=?";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
	}

}
