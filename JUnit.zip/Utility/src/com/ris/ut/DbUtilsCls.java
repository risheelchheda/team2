package com.ris.ut;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sat.mod.Register;

/**
 * Database Utility class which performs crud operation on a single table register
 * Class uses static blocks to initialize the connection
 * @author Risheel
 */

public class DbUtilsCls {
	private static Connection con=null;

	static {
		try {
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDBA","postgres","root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
					
		}
	
	/**
	 * Execute a select statement on table and stores the returned rows into a array list
	 * @return list of rows
	 * @author Risheel
	 */

	public List<Register> retRegs(){
		List<Register> lr=new ArrayList<>();
		String query="select * from public.\"register\"";
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				Register r=new Register(rs.getInt(1),rs.getString(2),rs.getString(3));
				lr.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lr;
	
	}
	
	/**
	 * Inserts a new row into the register table by taking inputs from the user
	 * @return status string
	 * @author Risheel
	 */
	
	public String insRec(Register r) {
		String status="Not done";
		try {
			PreparedStatement ps=con.prepareStatement("insert into public.\"register\"values(?,?,?)");	
			ps.setInt(1, r.getRid());
			ps.setString(2,r.getRname());
			ps.setString(3, r.getRemail());
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
		
	}
	
	/**
	 * Updates the name or the email for a particular rid
	 * @return status string
	 * @author Risheel
	 */
	public String updRec(Register r) {
		String status="Not done";
		try {
			PreparedStatement ps=con.prepareStatement("update public.\\\"register\\\" set rname=?,remail=? where rid=?\"");	
			
			ps.setString(1,r.getRname());
			ps.setString(2, r.getRemail());
			ps.setInt(3, r.getRid());
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
		
	}

	/**
	 * Deletes a row of the register table according to the rid
	 * @return status string
	 * @author Risheel
	 */
	
	public String delRec(int key) {
		String status="Not done";
		try {
			PreparedStatement ps=con.prepareStatement("delete from public.\"register\"where rid=?");		
			ps.setInt(1,key);
			status="done";
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
		
	}
	
}
