package com.ris.cls;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.instanceOf;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class NumCls {
	
	public double retSqrt(int a) {
		return Math.sqrt(a);
	}
	
	public double retLog(int a) {
		return Math.log10(a);
	}
	
	public double retPow(int a,int b) {
		return Math.pow(a, b);
	}
	
	public int[] retArr() {
		return new int[] {1,2,3,4,5};
	}
	
	public List<Integer> retList(){
		List<Integer> ls=new ArrayList<Integer>();
		ls=Stream.iterate(1, a->a+1).limit(20).toList();
		return ls;
	}

	public int retSqr(int a) {
		return a*a;
	}
	
	
}
