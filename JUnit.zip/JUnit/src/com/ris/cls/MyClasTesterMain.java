package com.ris.cls;

import java.sql.ResultSet;

import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.ris.cls.test.ClsUtilMainTestcase;

public class MyClasTesterMain {
	
	
	public static void main(String[] args) {
		
		//Running junit from main class or from console
		Request request=Request.method(ClsUtilMainTestcase.class, "testRetAltUp");
		Result res=new JUnitCore().run(request);
		for(Failure failure:res.getFailures()) {
			System.out.println(failure.getMessage());			
		}
		System.out.println(res.getFailureCount());
	}
}
