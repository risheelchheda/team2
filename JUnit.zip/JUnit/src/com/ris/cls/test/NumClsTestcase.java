package com.ris.cls.test;

import static org.junit.Assert.*;

import java.util.List;
import java.util.stream.Stream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ris.cls.NumCls;

public class NumClsTestcase {
	NumCls cls=null;

	@Before
	public void setUp() throws Exception {
		cls=new NumCls();
	}

	@After
	public void tearDown() throws Exception {
		cls=null;
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testRetSqrt() {
		double a=2.0;
		assertEquals(a, cls.retSqrt(4),0.0);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testRetLog() {
		double a=1.0;
		assertEquals(a, cls.retLog(10),0.0);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testRetPow() {
		double a=144.0;
		assertEquals(a, cls.retPow(12,2),0.0);
	}

	@Test
	public void testRetArr() {
		int[] arr= {1,2,3,4,5};
		assertArrayEquals(arr, cls.retArr());
	}
	
	@Test
	public void testRetList() {
		List<Integer> ls=Stream.iterate(1, a->a+1).limit(20).toList();
		assertArrayEquals(ls.toArray(), cls.retList().toArray());
	}
	
	@Test
	public void testRetSqr() {
		int a=4;
		assertEquals(a, cls.retSqr(2));
	}
	
	@Test
	public void testRetSqrtArray() {
		
	}

}
