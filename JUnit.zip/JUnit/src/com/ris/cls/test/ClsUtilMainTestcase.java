package com.ris.cls.test;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ris.cls.ClsUtilMain;

public class ClsUtilMainTestcase {
	ClsUtilMain cls=null;

	@Before
	public void setUp() throws Exception {
		cls=new ClsUtilMain();
	}

	@After
	public void tearDown() throws Exception {
		cls=null;
	}

	@Test
	public void testRetAltUp() {
		String finString="RiShEEL";
		assertEquals(finString, cls.retAltUp("risheel"));
	}

}
