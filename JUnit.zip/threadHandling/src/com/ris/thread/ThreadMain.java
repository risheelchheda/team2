package com.ris.thread;

public class ThreadMain {
	public static void main(String[] args) {
		MyTr t=new MyTr();
		MyTrA t1=new MyTrA();
		t.start();
		t1.run();
		System.out.println("*************************Starting Thread"); //This line runs before the previous line
		
		Thread aa=new Thread(new Runnable() {
			public void run() {
				System.out.println("Inside Thread");
			}
			
		}
		);
		aa.start();
		
		new Runnable() {
			public void run() {
				System.out.println("Another Thread");
			};
		}.run();
	}
}
