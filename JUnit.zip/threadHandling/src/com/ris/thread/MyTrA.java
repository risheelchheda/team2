package com.ris.thread;

public class MyTrA implements Runnable {

	@Override
	public void run() {
		for(int i=0;i<1000;i++) {
			System.out.println("******************************************"+Math.log(i));
		}
	}

}
