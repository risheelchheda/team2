package com.ris.thread;

public class MyTr extends Thread {

	@Override
	public void run() {
		//super.run();
		for(int i=0;i<1000;i++) {
			System.out.println(Math.sqrt(i));
		}
	}
	
}
