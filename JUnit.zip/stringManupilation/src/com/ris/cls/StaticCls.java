package com.ris.cls;

import java.lang.reflect.Array;

public class StaticCls {
	
	private static int a=100; //To use it in a static block we need a static variable
	
	static {
		System.out.println("This is a static block "+a); //This is a static block and will be called when the first object of the class is create
	}
	/***
	 * This is called documentation it is usually used to write the name of the author
	 * or the return type of the function or the parameters that are used by the function
	 */
	
	public StaticCls() {
		System.out.println("This is a constructor");
	}
	
	public static void tester() {
		System.out.println("This is a test method from other class");
	}
	
	public void testerA() {
		System.out.println("This is a non static tester method");
	}
	
	//Using math class
	/***
	 * This method is used to calculate the square root of 1000 numbers as a semi colon
	 * delimited string
	 *@return String
	 *@author Risheel
	 */
	
	public String retSqrts() {
		String res="";
		for(int i=0;i<1001;i++) {
			res+="Sqrt("+i+")="+Math.sqrt(i)+";";
		}
		return res;
	}
	
	public String retLogs() {
		String res="";
		for(int i=1;i<1001;i++) {
			res+="Log("+i+")="+Math.log(i)+";";
		}
		return res;
	}
	
	public double sumOfSquares(int a,int b) {
		return Math.sqrt(a*a+b*b);
	}
	
	public double area(double b,double h) {
		return (0.5*h)*b;
	}
	
	public double[] area(double[] b,double[] h) {
		double[] area=new double[10];
		for(int i=0;i<10;i++) {
			area[i]=(0.5*b[i]*h[i]);
		}
		return area;
	}

}
