package com.ris.cls;

import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class MyCls {

	public static void main(String[] args) {
		//Basic methods of String Manipulation
		String str="This is a string for testing.";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.substring(0,7));
		System.out.println(str.charAt(5));
		System.out.println(str.concat("This is my String"));
		
		
		//Using String Buffer
		StringBuffer stb=new StringBuffer();
		stb.append(str);
		for(int i=0;i<24;i++) {
			stb.append((char)(i+94));
		}
		System.out.println(stb.toString());
		
		//Using String Builder
		StringBuilder stbu=new StringBuilder();
		stbu.append(str);
		for(int i=0;i<26;i++) {
			stbu.append((char)(i+97));
		}
		System.out.println(stbu.toString());
		
		//Conversion of char to String 
		char a='a';
		System.out.println(String.valueOf(a).toUpperCase());
		
		//Conversion of string to int
		String i="44";
		System.out.println(Integer.parseInt(i));
		
		//Reversing a String using string Buffer
		System.out.println(stb.reverse());
		
		
		
		//Meaning of Static Classes
		StaticCls.tester();//In static methods you do not need an object to call the method
		StaticCls obj=new StaticCls();
		obj.testerA();//In a non static class you need an object to call the method
		
		for(int j=0;j<5;j++) {
			StaticCls obj1=new StaticCls();
			obj1.testerA();
		}
		
	
		
		//Using math class
		String u=obj.retSqrts();
		String[] sArr=u.split(";");
		for(String b:sArr) {
			System.out.println(b);
		}
		
		
		//Splitting using tokenizer
		StringTokenizer stk=new StringTokenizer(u,";");
		while(stk.hasMoreTokens()) {
			System.out.println(stk.nextToken());
		}
		System.out.println("**************************************************");
		//Using another way here nextElement returns object 
		while(stk.hasMoreElements()) {
			String ua=String.valueOf(stk.nextElement());
			System.out.println(ua);
		}
		System.out.println("**************************************************");
		
		
		//Converting array to list
		String logs=obj.retLogs();
		List<String> lst=Arrays.asList(logs.split(";"));
		for(String c:lst) {
			System.out.println(c);
		}
		
		System.out.println(Math.round(obj.sumOfSquares(3,4)));
		System.out.printf("The sum of squares of %d and %d is %d\n",3,4,(int)obj.sumOfSquares(3, 4));
		System.out.println(obj.area(5.1, 6.5));
		double[] h= {1,5,3,6,1,6,7,3,8,9};
		double[] b= {4,1,5,7,8,4,9,1,4,5};
		double[] area=obj.area(h, b);
		for(double ans:area) {
			System.out.println(ans);
		}
		}

}
