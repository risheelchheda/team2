package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.sms.models.Perks;
import com.sms.services.IPerksDao;
import com.sms.utils.DbUtilClass;
import com.sms.utils.PropertyUtils;

public class PerksDaoImpl implements IPerksDao{
	
	private Connection connection = DbUtilClass.getDBConnection();
	private Properties props = PropertyUtils.getProperties();
	private String perkString = props.getProperty("perk");
	
	@Override
	public Perks getPerk(String grade) {
		
		Perks perks =null;
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+perkString+" WHERE grade = '"+grade+"'");
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return perks;
			resultSet.next();
			perks = new Perks(resultSet.getString(1),resultSet.getDouble(2),resultSet.getDouble(3),resultSet.getDouble(4),resultSet.getDouble(5),resultSet.getDouble(6));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return perks;
	}

	@Override
	public int updatePerk(Perks perk) {
		
		int status= -1;
		
		try {
			PreparedStatement statement = connection.prepareStatement("UPDATE "+perkString+" SET medicalInsurance=?, travelReimburse=?, fitnessAllowances=?, mobileReimburse=?, certificationReimburse=? where grade=?");
			statement.setString(6, perk.getGrade());
			statement.setDouble(1, perk.getMedicalInsurance());
			statement.setDouble(2, perk.getTravelReimburse());
			statement.setDouble(3, perk.getFitnessAllowances());
			statement.setDouble(4, perk.getMobileReimburse());
			statement.setDouble(5, perk.getCertificationReimburse());
			
			status = statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
	}
	@Override
	public List<String> getGrades() {
		List<String> gradeList=new ArrayList<String>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT grade from "+perkString);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				gradeList.add(resultSet.getString(1));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return gradeList;
	}

	@Override
	public List<Perks> getPerks() {
		List<Perks> perks = new ArrayList<Perks>();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement("SELECT * FROM "+perkString);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return perks;
			while (resultSet.next()) {
				Perks perk = new Perks(resultSet.getString(1), resultSet.getDouble(2), resultSet.getDouble(3), resultSet.getDouble(4), resultSet.getDouble(5), resultSet.getDouble(6));
				perks.add(perk);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return perks;
	}

}
