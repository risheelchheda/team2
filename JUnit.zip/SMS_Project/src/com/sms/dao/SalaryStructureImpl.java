package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.sms.models.SalaryStructure;
import com.sms.services.ISalaryStructureDao;
import com.sms.utils.DbUtilClass;
import com.sms.utils.PropertyUtils;

public class SalaryStructureImpl implements ISalaryStructureDao{

	private Connection connection = DbUtilClass.getDBConnection();
	private Properties props = PropertyUtils.getProperties();
	private String salStrString = props.getProperty("salStr");
	
	@Override
	public SalaryStructure getSalaryStructure(int empId) {
		
		SalaryStructure salStr=null;
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+salStrString+" WHERE empId="+empId);
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return salStr;
			resultSet.next();
			salStr = new SalaryStructure(resultSet.getInt(1),resultSet.getDouble(2),resultSet.getDouble(3),resultSet.getDouble(4),resultSet.getDouble(5),resultSet.getDouble(6));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return salStr;
	}

	@Override
	public int updateSalaryStructure(SalaryStructure salStr) {
		
		
		int status = 0;
		try {
			PreparedStatement statement = connection.prepareStatement("UPDATE "+salStrString+" SET basic=?, hra=?, da=?, pf=?, tax=? WHERE empId=?");
			statement.setInt(6, salStr.getEmpId());
			statement.setDouble(1, salStr.getBasic());
			statement.setDouble(2, salStr.getHRA());
			statement.setDouble(3, salStr.getDA());
			statement.setDouble(4, salStr.getPF());
			statement.setDouble(5, salStr.getTax());
			
			status = statement.executeUpdate();
			status=1;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int deleteSalaryStructure(int empId) {
		int status = 0;

		try {
			PreparedStatement statement = connection.prepareStatement("DELETE FROM "+salStrString+" WHERE empid=?");
			statement.setInt(1, empId);
			status = statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int addSalaryStructure(SalaryStructure salStr) {
		
		int status = 0;

		try {
			PreparedStatement statement = connection.prepareStatement("INSERT INTO "+salStrString+" VALUES (?,?,?,?,?,?)");
			statement.setInt(1, salStr.getEmpId());
			statement.setDouble(2, salStr.getBasic());
			statement.setDouble(3, salStr.getHRA());
			statement.setDouble(4, salStr.getDA());
			statement.setDouble(5, salStr.getPF());
			statement.setDouble(6, salStr.getTax());

			status=statement.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}	
	 
}
