package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.sms.models.Employee;
import com.sms.services.IEmployeeDao;
import com.sms.utils.DbUtilClass;
import com.sms.utils.PropertyUtils;

public class EmployeeDaoImpl implements IEmployeeDao{

	private Connection connection = DbUtilClass.getDBConnection();
	private Properties props = PropertyUtils.getProperties();

	@Override
	public List<Employee> getEmployees() {

		List<Employee> employeeList = new ArrayList<Employee>();
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+props.getProperty("emp"));
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return employeeList;
			while (resultSet.next()) {
				Employee employee = new Employee(
						resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8));
				employeeList.add(employee);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return employeeList;
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee employee = null;
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM "+props.getProperty("emp")+"WHERE empId="+empId);
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return employee;
			resultSet.next();
			employee = new Employee(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),resultSet.getString(7),resultSet.getString(8));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employee;
	}

	@Override
	public String addEmployee(Employee emp) {

		String status="Not Done";
		int employeeId=-1;

		try {
			PreparedStatement statement = connection.prepareStatement("INSERT INTO "+props.getProperty("emp")+" (empName, empEmail, empPhone, empAddress, empDepartment, empDesignation, empGrade) VALUES (?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, emp.getEmpName());
			statement.setString(2, emp.getEmpEmail());
			statement.setString(3, emp.getEmpPhone());
			statement.setString(4, emp.getEmpAddress());
			statement.setString(5, emp.getEmpDepartment());
			statement.setString(6, emp.getEmpDesignation());
			statement.setString(7, emp.getEmpGrade());

			status =Integer.toString(statement.executeUpdate());
			
			ResultSet resultSet = statement.getGeneratedKeys();
			if(resultSet.next()) {
				employeeId = resultSet.getInt(1);
				status=status+":"+employeeId;
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int updateEmployee(Employee emp) {
		int status=0;

		try {
			PreparedStatement statement = connection.prepareStatement("UPDATE "+props.getProperty("emp")+" SET empName=?, empEmail=?, empPhone=?, empAddress=?, empDepartment=?, empDesignation=?, empGrade=? WHERE empid=?");
			statement.setString(1, emp.getEmpName());
			statement.setString(2, emp.getEmpEmail());
			statement.setString(3, emp.getEmpPhone());
			statement.setString(4, emp.getEmpAddress());
			statement.setString(5, emp.getEmpDepartment());
			statement.setString(6, emp.getEmpDesignation());
			statement.setString(7, emp.getEmpGrade());
			statement.setInt(8, emp.getEmpId());

			status=statement.executeUpdate();

			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int deleteEmploye(int empId) {
		int status = 0;

		try {
			PreparedStatement statement = connection.prepareStatement("DELETE FROM "+props.getProperty("emp")+" WHERE empid=?");
			statement.setInt(1, empId);
			status = statement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

	@Override
	public String getEmpPhone(int empId) {
		String phone="";
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT empPhone FROM "+props.getProperty("emp")+"WHERE empId="+empId);
			ResultSet resultSet = statement.executeQuery();
			if(!resultSet.isBeforeFirst())
				return "-1";
			resultSet.next();
			phone=resultSet.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return phone;
	}

	@Override
	public String getEmpGrade(int empId) {
		String grade="";
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT empGrade FROM "+props.getProperty("emp")+"WHERE empId="+empId);
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			grade=resultSet.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return grade;
	}

}
