package com.sms.main;

import java.util.Properties;
import java.util.Scanner;

import com.sms.utils.EmployeeUtils;
import com.sms.utils.PayrollUtils;
import com.sms.utils.PerksUtils;
import com.sms.utils.PropertyUtils;
import com.sms.utils.SalaryStructureUtils;

public class SMS_Admin {

	Scanner sc = new Scanner(System.in);
	EmployeeUtils employeeUtils = new EmployeeUtils();
	SalaryStructureUtils salaryStructureUtils = new SalaryStructureUtils();
	PerksUtils perksUtils = new PerksUtils();
	PayrollUtils payrollUtils = new PayrollUtils();
	Properties props = PropertyUtils.getProperties();

	public void getAdminLogin() {

		System.out.print("Enter AdminId : ");
		String adminId = sc.nextLine();
		System.out.print("Enter Admin Password : ");
		String adminPassword = sc.nextLine();

		if( (props.getProperty("adminId")).equals(adminId) && (props.getProperty("adminPassword")).equals(adminPassword))
		{
			getAdminMenu();
		}
		else {
			System.out.println("Wrong Id/ Password (Press enter to continue)");
			sc.nextLine();
			SalaryManagementSystem.main(null); 
		}
	}



	public void getAdminMenu() {

		System.out.println("====================================================================");
		System.out.println("                       Welcome to Admin Portal                      ");
		System.out.println("====================================================================");
		System.out.println("1.Employee\n2.Perks\n3.Salary Structure\n4.Payroll\n5.LogOut");
		System.out.println("Enter Your Choice");
		int ch = sc.nextInt();
		sc.nextLine();

		switch (ch) {
		case 1:
			getAdminEmployeeMenu();
			break;
		case 2:
			getAdminPerksMenu();
			break;
		case 3:
			getAdminSalaryStructureMenu();
			break;
		case 4:
			getAdminPayrollMenu();
			break;
		case 5:
			System.out.println("Press Enter to Logout");
			sc.nextLine();
			SalaryManagementSystem.main(null);
			break;
		default:
			System.out.println("Wrong choice!");
			getAdminMenu();
			return;
		}

		sc.close();
	}

	public void getAdminEmployeeMenu() {
		System.out.println("====================================================================");
		System.out.println("                           Employee Menu                            ");
		System.out.println("====================================================================");
		System.out.println("1.Add Employee\n2.Get All Employees \n3.Get an Employee\n4.Update Employee Details\n5.Delete Employee\n6.Admin Menu");
		System.out.println("Enter Your Choice");
		int ch = sc.nextInt();
		sc.nextLine();

		switch (ch) {
		case 1:
			if(employeeUtils.addEmployee()) {
				System.out.println("Employee added Successfully");
			}
			else {
				System.out.print("Employee can not be added! Please try again later.");
			}
			System.out.println("Press Enter to go back to Employee Menu");
			sc.nextLine();
			getAdminEmployeeMenu();
			break;
		case 2:
			employeeUtils.getEmployees();
			System.out.println("Press Enter to go back to Employee Menu");
			sc.nextLine();
			getAdminEmployeeMenu();

			break;
		case 3:
			employeeUtils.getEmployee();
			System.out.println("Press Enter to go back to Employee Menu");
			sc.nextLine();
			getAdminEmployeeMenu();
			break;
		case 4:
			if(employeeUtils.updateEmployee()) {
				System.out.println("Employee Updated Successfully");
			}
			else {
				System.out.println("No employee with given employee Id");
			}
			System.out.println("Press Enter to go back to Employee Menu");
			sc.nextLine();
			getAdminEmployeeMenu();
			break;
		case 5:
			if(employeeUtils.deleteEmployee()) {
				System.out.println("Employee Deleted Successfully");
			}
			else {
				System.out.print("Employee can not be deleted!");
			}
			System.out.println("Press Enter to go back to Employee Menu");
			sc.nextLine();
			getAdminEmployeeMenu();
			break;
		case 6:
			System.out.println("Press Enter to go back to Admin Menu");
			sc.nextLine();
			getAdminMenu();
			break;

		default:
			System.out.println("Wrong Choice! Taking you back to Admin Menu");
			System.out.println("Press Enter to continue");
			sc.nextLine();
			getAdminMenu();
			break;
		}
	}

	public void getAdminSalaryStructureMenu() {
		System.out.println("====================================================================");
		System.out.println("                        Salary Structure Menu                       ");
		System.out.println("====================================================================");
		System.out.println("1.Get Salary Structure \n2.Update Salary Structure\n3.Admin Menu");
		System.out.println("Enter Your Choice");
		int ch = sc.nextInt();
		sc.nextLine();

		switch (ch) {
		case 1:
			salaryStructureUtils.getSalaryStructure();;
			System.out.println("Press Enter to go back to Salary Structure Menu");
			sc.nextLine();
			getAdminSalaryStructureMenu();
			break;
		case 2:
			if(salaryStructureUtils.updateSalaryStructure())
				System.out.println("Salary Structure Updated Successfully");
			else {
				System.out.println("Not able to update the salary structure! Try Again Later");
				}
			System.out.println("Press Enter to go back to Salary Structure Menu");
			sc.nextLine();
			getAdminSalaryStructureMenu();
			break;
		case 3:
			System.out.println("Press Enter to go back to Admin Menu");
			sc.nextLine();
			getAdminMenu();
			break;
		default:
			System.out.println("Wrong Choice! Taking you back to Admin Menu");
			System.out.println("Press Enter to continue");
			sc.nextLine();
			getAdminMenu();
			break;
		}
	}

	public void getAdminPayrollMenu() {
		System.out.println("====================================================================");
		System.out.println("                           Payroll Menu                             ");
		System.out.println("====================================================================");
		System.out.println("1.Add new Payroll\n2.Get Payroll by Employee Id \n3.Get payroll by Month & Year \n4.Admin Menu");
		System.out.println("Enter Your Choice");
		int ch = sc.nextInt();
		sc.nextLine();

		switch (ch) {
		case 1:
			if(payrollUtils.addPayroll()) {
				System.out.println("Payroll added Successfully");
			}
			else {
				System.out.print("Payroll can not be added! Please try again later.");
			}
			System.out.println("Press Enter to go back to Payroll Menu");
			sc.nextLine();
			getAdminPayrollMenu();
			break;
		case 2:
			payrollUtils.getPayrolls();
			System.out.println("Press Enter to go back to Payroll Menu");
			sc.nextLine();
			getAdminPayrollMenu();
			break;
		case 3:
			payrollUtils.getPayroll();
			System.out.println("Press Enter to go back to Payroll Menu");
			sc.nextLine();
			getAdminPayrollMenu();
		case 4:
			System.out.println("Press Enter to go back to Admin Menu");
			sc.nextLine();
			getAdminMenu();
			break;
		default:
			System.out.println("Wrong Choice! Taking you back to Admin Menu");
			System.out.println("Press Enter to continue");
			sc.nextLine();
			getAdminMenu();
			break;
		}
	}

	public void getAdminPerksMenu() {
		System.out.println("====================================================================");
		System.out.println("                            Perks Menu                              ");
		System.out.println("====================================================================");
		System.out.println("1.Get Perks \n2.Get Perks by Grade\n3.Update Perks \n4.Admin Menu");
		System.out.println("Enter Your Choice");
		int ch = sc.nextInt();
		sc.nextLine();

		switch (ch) {
		case 1:
			perksUtils.getPerks();
			System.out.println("Press Enter to go back to Perks Menu");
			sc.nextLine();
			getAdminPerksMenu();
			break;
		case 2:
			perksUtils.getPerk();
			System.out.println("Press Enter to go back to Perks Menu");
			sc.nextLine();
			getAdminPerksMenu();
			break;
		case 3:
			perksUtils.updatePerks();
			System.out.println("Press Enter to go back to Perks Menu");
			sc.nextLine();
			getAdminPerksMenu();
			break;
		case 4:
			System.out.println("Press Enter to go back to Admin Menu");
			sc.nextLine();
			getAdminMenu();
			break;
		default:
			System.out.println("Wrong Choice! Taking you back to Admin Menu");
			System.out.print("Press Enter to continue : ");
			sc.nextLine();
			getAdminMenu();
			break;
		}
	}
}
