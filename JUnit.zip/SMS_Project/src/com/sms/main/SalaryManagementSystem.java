package com.sms.main;

import java.util.Scanner;


public class SalaryManagementSystem {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("====================================================================");
		System.out.println("               Welcome to Salary Management System                  ");
		System.out.println("====================================================================");
		System.out.println("1.Admin \n2.Employee\n3.Exit");
		System.out.println("Enter Your Choice");
		int choice = sc.nextInt();
		sc.nextLine();
		switch (choice) {
			case 1:
					SMS_Admin sms_Admin =new SMS_Admin();
					sms_Admin.getAdminLogin();
				break;
			case 2:
					SMS_Employee sms_Employee = new SMS_Employee();
					sms_Employee.getEmployeeLogin();
				break;
			case 3:
				System.out.println("Press Enter to Exit the Application");
				sc.nextLine();
				break;
			default:
				break;
		}
		sc.close();
	}
}

