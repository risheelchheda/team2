package com.sms.services;

import java.util.List;

import com.sms.models.Perks;

public interface IPerksDao {
	
	public Perks getPerk(String grade);
	public List<Perks> getPerks();
	public int updatePerk(Perks perk);
	public List<String> getGrades();
}
