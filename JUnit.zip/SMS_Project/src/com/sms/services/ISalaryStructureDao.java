package com.sms.services;

import com.sms.models.SalaryStructure;

public interface ISalaryStructureDao {

	public SalaryStructure getSalaryStructure(int empId);
	public int updateSalaryStructure(SalaryStructure salStr);
	public int deleteSalaryStructure(int empId);
	public int addSalaryStructure(SalaryStructure salStr);
}
