package com.sms.services;

import java.util.List;

import com.sms.models.Payroll;

public interface IPayrollDao {
	
	public List<Payroll> getPayrolls(int empId);
	public Payroll getPayroll(int empId, int month, int year);
	public int addPayroll(Payroll payroll);
	public int deletePayrolls(int empId);
	
	
}
