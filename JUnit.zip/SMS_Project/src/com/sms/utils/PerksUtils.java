package com.sms.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.sms.dao.PerksDaoImpl;
import com.sms.models.Perks;

public class PerksUtils {

	Scanner sc = new Scanner(System.in);
	PerksDaoImpl perksDaoImpl =new PerksDaoImpl();
	
	public void getPerk() {
		
		String grade;
		System.out.println("Enter Grade : ");
		grade=sc.nextLine();
		
		Perks perks = perksDaoImpl.getPerk(grade);
		if(perks==null)
			System.out.println("No Perks for given grade");
		else {
			System.out.println(perks);
		}
	}

	public void updatePerks() {
		
		String grade;
		System.out.println("Enter Grade : ");
		grade=sc.nextLine();
		
		System.out.println("Enter amount for Medical Insurance : ");
		double medicalInsurance = sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter amount for Travel Reimbursement : ");
		double travelReimburse = sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter amount for Fitness Allowances : ");
		double fitnessAllowances = sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter amount for Mobile Reimbursement : ");
		double mobileReimburse = sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter amount for Certification Reimbursement : ");
		double CertificationReimburse = sc.nextDouble();
		sc.nextLine();
		
		Perks perks = new Perks(grade, medicalInsurance, travelReimburse, fitnessAllowances, mobileReimburse, CertificationReimburse);
		
		perksDaoImpl.updatePerk(perks);
		
	}

	public void getPerks() {
		List<Perks> perks=perksDaoImpl.getPerks();
		if(perks==null)
			System.out.println("No perks to show");
		else {
			Iterator<Perks> iterator = perks.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}
		
	}
	
}
