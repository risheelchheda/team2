package com.sms.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtilClass {
	public static Connection getDBConnection()
	{
		Connection connection = null;
		Properties props=PropertyUtils.getProperties();
		

		try {

			Class.forName(props.getProperty("drivername"));
			connection = DriverManager.getConnection(props.getProperty("connectionString")+props.getProperty("dbName"),props.getProperty("username"),props.getProperty("password"));

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 

		return connection;

	}
}
