package com.sms.utils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtils {
	
	public static Properties getProperties()
	{
		Properties props = null;
		
		FileReader fileReader;
		try {
			fileReader = new FileReader(new File("C:\\Users\\localadmin\\Desktop\\Training\\SMS_Project\\src\\app.properties"));
			props = new Properties();
			props.load(fileReader);
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		return props;
	}
}
