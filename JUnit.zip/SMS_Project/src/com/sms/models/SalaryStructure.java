package com.sms.models;

public class SalaryStructure {
	
    private int empId; 
    private double basic;
    private double HRA; //50%
    private double DA; //20%
    private double PF; //12%
    private double tax; 
    
//    Getters & Setters

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	public double getHRA() {
		return HRA;
	}
	public void setHRA(double hRA) {
		HRA = hRA;
	}
	public double getDA() {
		return DA;
	}
	public void setDA(double dA) {
		DA = dA;
	}
	public double getPF() {
		return PF;
	}
	public void setPF(double pF) {
		PF = pF;
	}
	public double getTax() {
		return tax;
	}
	public void setTax(double tax) {
		this.tax = tax;
	}
	
//	Constructors
	public SalaryStructure() {
		// TODO Auto-generated constructor stub
	}
	public SalaryStructure(int empId, double basic, double HRA, double DA, double PF,
			double tax) {
		super();
		this.empId = empId;
		this.basic = basic;
		this.HRA = HRA;
		this.DA = DA;
		this.PF = PF;
		this.tax = tax;
	}
	
//	toString
	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();

        sb.append("====================================================================\n");
        sb.append("                         Salary Structure                           \n");
        sb.append("====================================================================\n");
        sb.append(String.format("| %-35s | %26d |\n", "Employee Id", empId));
        sb.append(String.format("| %-35s | %26.2f |\n", "Basic", basic));
        sb.append(String.format("| %-35s | %26.2f |\n", "HRA", HRA));
        sb.append(String.format("| %-35s | %26.2f |\n", "DA", DA));
        sb.append(String.format("| %-35s | %26.2f |\n", "PF", PF));
        sb.append(String.format("| %-35s | %26.2f |\n", "Tax", tax));
        sb.append("====================================================================\n");

        // Return the constructed string
        return sb.toString();
	}
}
