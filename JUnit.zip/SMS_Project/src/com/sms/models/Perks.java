package com.sms.models;

public class Perks {
	private String grade; // Primary key
	private double medicalInsurance;
	private double travelReimburse;
	private double fitnessAllowances;
	private double mobileReimburse;
	private double certificationReimburse;


//	Getters & Setters
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public double getMedicalInsurance() {
		return medicalInsurance;
	}
	public void setMedicalInsurance(double medicalInsurance) {
		this.medicalInsurance = medicalInsurance;
	}
	public double getTravelReimburse() {
		return travelReimburse;
	}
	public void setTravelReimburse(double travelReimburse) {
		this.travelReimburse = travelReimburse;
	}
	public double getFitnessAllowances() {
		return fitnessAllowances;
	}
	public void setFitnessAllowances(double fitnessAllowances) {
		this.fitnessAllowances = fitnessAllowances;
	}
	public double getMobileReimburse() {
		return mobileReimburse;
	}
	public void setMobileReimburse(double mobileReimburse) {
		this.mobileReimburse = mobileReimburse;
	}
	public double getCertificationReimburse() {
		return certificationReimburse;
	}
	public void setCertificationReimburse(double certificationReimburse) {
		this.certificationReimburse = certificationReimburse;
	}

	
//    Constructors
	public Perks() {
		// TODO Auto-generated constructor stub
	}
	public Perks(String grade, double medicalInsurance, double travelReimburse, double fitnessAllowances,
			double mobileReimburse, double certificationReimburse) {
		super();
		this.grade = grade;
		this.medicalInsurance = medicalInsurance;
		this.travelReimburse = travelReimburse;
		this.fitnessAllowances = fitnessAllowances;
		this.mobileReimburse = mobileReimburse;
		this.certificationReimburse = certificationReimburse;
	}

//	toString
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

        sb.append("====================================================================\n");
        sb.append("                             Perks Details                          \n");
        sb.append("====================================================================\n");
        sb.append(String.format("| %-32s | %28s |\n", "Grade", grade));
        sb.append(String.format("| %-32s | %28.2f |\n", "Medical Insurance", medicalInsurance));
        sb.append(String.format("| %-32s | %28.2f |\n", "Travel Reimbursement", travelReimburse));
        sb.append(String.format("| %-32s | %28.2f |\n", "Fitness Allowances", fitnessAllowances));
        sb.append(String.format("| %-32s | %28.2f |\n", "Mobile Reimbursement", mobileReimburse));
        sb.append(String.format("| %-32s | %28.2f |\n", "Certification Reimbursement", certificationReimburse));
        sb.append("====================================================================\n");

        // Return the constructed string
        return sb.toString();
	}

	

}