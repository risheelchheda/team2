package com.ris.cls;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount[] baArr=new BankAccount[3];
		String arr1[]= {"111","222","333","444","555","666"};
		String arr2[]= {"IOB","ICICI","HDFC","HSBC","RBS"};
		String arr3[]= {"A213BH","H713491H","SD398HU","DUOSAB39"};
		String arr4[]= {"saving","current"};
		for(int i=0;i<3;i++) {
			BankAccount acc=new BankAccount(arr1[i],arr4[i%2]);
			baArr[i]=acc;			
		}
//		BankCls bank=new BankCls(arr3[0],arr2[0],baArr);
		BankCls bArr[]=new BankCls[3];
		for(int j=0;j<3;j++) {
			bArr[j]=new BankCls(arr3[j],arr2[j],baArr);
		}

	}

}
