package com.ris.cls;

public class Employee {
	
	private int eId;
	private String eName;
	private String eDesign;
	private double eSal;
	
	public Employee() {
		
	}
	
	public Employee(int id,String name,String designation,double sal) {
		this.eId=id;
		this.eName=name;
		this.eDesign=designation;
		this.eSal=sal;
	}
	
	public String toString() {
		String f=String.format("Id:%d\nName:%s\nDesignation:%s\nSalary:%.2f\n\n",this.eId,this.eName,this.eDesign,this.eSal);
		return f;
	}
	
	
	
	

}
