package com.ris.cls;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// This code is for Student Class
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter the number of students");
		int i=Integer.parseInt(scan.nextLine());
		
		Student[] students=new Student[i];
		int j=0;
		while(j<i) {
			System.out.println("Enter the Id of the Student");
			int id=Integer.parseInt(scan.nextLine());
			System.out.println("Enter the name of the Student");
			String name=scan.nextLine();
			System.out.println("Enter the email of the Student");
			String email=scan.nextLine();
			System.out.println("Enter the cgpa of the Student");
			float cgpa=Float.parseFloat(scan.nextLine());
			Student std=new Student();
			std.setsId(id);
			std.setsName(name);
			std.setsEmail(email);
			std.setsCgpa(cgpa);
			students[j]=std;
			j++;
		}
		
		String u=Arrays.deepToString(students);
		System.out.println(u);
		for(Student s:students) {
			System.out.println(s);
		}
		System.out.println("**********************");
		
		
		//****************************************************************************
		//This is for employee class
		Employee[] eArr=new Employee[2];
		for(int k=0;k<2;k++) {
			System.out.println("Enter the name:");
			String name=scan.nextLine();
			System.out.println("Enter the Designation");
			String designation=scan.nextLine();
			System.out.println("Enter your Salary");
			int sal=Integer.parseInt(scan.nextLine());
			eArr[k]=new Employee(k+1,name,designation,sal);
		}
		for(Employee e:eArr) {
			System.out.println(e);
		}
		
	}
	
	

}
