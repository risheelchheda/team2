package com.ris.cls;

public class Student {
	
	
	private int sId;
	private String sName;
	private String sEmail;
	private float sCgpa;
	
	public int getsId() {
		return sId;
	}
	
	public void setsId(int sId) {
		this.sId = sId;
	}
	
	public String getsName() {
		return sName;
	}
	
	public void setsName(String sName) {
		this.sName = sName;
	}
	
	public String getsEmail() {
		return sEmail;
	}
	
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	
	public float getsCgpa() {
		return sCgpa;
	}
	
	public void setsCgpa(float sCgpa) {
		this.sCgpa = sCgpa;
	}
	
	public String toString() {
		String fin=String.format("Name:%s\nClass:%s\nId:%d\nCgpa:%f",sName,sEmail,sId,sCgpa);
		System.out.println(fin);
		return this.sId+" "+this.sName+" "+this.sEmail+" "+this.sCgpa;
	}
	
	

}
