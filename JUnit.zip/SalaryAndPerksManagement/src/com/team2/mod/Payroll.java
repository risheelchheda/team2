package com.team2.mod;


/**
 * The {@code Payroll} class represents an employee's payroll record.
 * It contains details such as employee ID, pay month, pay year, working days,
 * leave without pay (LWP), gross earnings, deductions, and net salary.
 * This class provides getters and setters to access and modify payroll information.
 * It also provides a default constructor and a parameterized constructor to initialize the object.
 * @author Risheel
 **/
public class Payroll {
	private int payId;
	private int empId;
	private int payMonth;
	private int payYear;
	private int workingDays;
	private int daysWorked;
	private int lwp;
	private double grossEarning;
	private double deduction;
	private double netSalary;

	public Payroll() {
	}

	public Payroll(int empId, int payMonth, int payYear, int workingDays, int daysWorked) {
		this.empId = empId;
		this.payMonth = payMonth;
		this.payYear = payYear;
		this.workingDays = workingDays;
		this.daysWorked = daysWorked;
	}

	public int getPayId() {
		return payId;
	}

	public void setPayId(int payId) {
		this.payId = payId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getPayMonth() {
		return payMonth;
	}

	public void setPayMonth(int payMonth) {
		this.payMonth = payMonth;
	}

	public int getPayYear() {
		return payYear;
	}

	public void setPayYear(int payYear) {
		this.payYear = payYear;
	}

	public int getWorkingDays() {
		return workingDays;
	}

	public void setWorkingDays(int workingDays) {
		this.workingDays = workingDays;
	}

	public int getDaysWorked() {
		return daysWorked;
	}

	public void setDaysWorked(int daysWorked) {
		this.daysWorked = daysWorked;
	}

	public int getLwp() {
		return lwp;
	}

	public void setLwp(int lwp) {
		this.lwp = lwp;
	}

	public double getGrossEarning() {
		return grossEarning;
	}

	public void setGrossEarning(double grossEarning) {
		this.grossEarning = grossEarning;
	}

	public double getDeduction() {
		return deduction;
	}

	public void setDeduction(double deduction) {
		this.deduction = deduction;
	}

	public double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

	@Override
	public String toString() {
		return "Payroll [payId=" + payId + ", empId=" + empId + ", payMonth=" + payMonth + ", payYear=" + payYear
				+ ", workingDays=" + workingDays + ", daysWorked=" + daysWorked + ", lwp=" + lwp + ", grossEarning="
				+ grossEarning + ", deduction=" + deduction + ", netSalary=" + netSalary + "]";
	}

}
