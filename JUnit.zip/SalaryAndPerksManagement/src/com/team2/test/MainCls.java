package com.team2.test;

import java.util.List;


import com.team2.dao.PayrollImpl;
import com.team2.mod.Payroll;

public class MainCls {
	public static void main(String[] args) {
		PayrollImpl payroll=new PayrollImpl();
		Payroll payroll1 = new Payroll(1, 1, 2024, 30, 28); // Employee 1
        Payroll payroll2 = new Payroll(2, 1, 2024, 30, 26); // Employee 2
        Payroll payroll3 = new Payroll(3, 1, 2024, 30, 27); // Employee 3
        Payroll payroll4 = new Payroll(4, 1, 2024, 30, 30); // Employee 4
        Payroll payroll5 = new Payroll(5, 1, 2024, 30, 25); // Employee 5
        Payroll payroll6 = new Payroll(6, 1, 2024, 30, 29); // Employee 6
        Payroll payroll7 = new Payroll(7, 1, 2024, 30, 22); // Employee 7
        Payroll payroll8 = new Payroll(8, 1, 2024, 30, 24); // Employee 8
        Payroll payroll9 = new Payroll(9, 1, 2024, 30, 26); // Employee 9
        Payroll payroll10 = new Payroll(10, 1, 2024, 30, 25); //Employee 10
        
//        System.out.println(payroll.insPayroll(payroll1));
//                System.out.println(payroll.insPayroll(payroll2));
//                System.out.println(payroll.insPayroll(payroll3));
//
//                System.out.println(payroll.insPayroll(payroll4));
//
//                System.out.println(payroll.insPayroll(payroll5));
//
//                System.out.println(payroll.insPayroll(payroll6));
//
//                System.out.println(payroll.insPayroll(payroll7));
//
//                System.out.println(payroll.insPayroll(payroll8));
//
//                System.out.println(payroll.insPayroll(payroll9));
//
//                System.out.println(payroll.insPayroll(payroll10));

	//                System.out.println(payroll.retPayrolls());
//        		System.out.println(payroll.retPayroll(6));
		
//			System.out.println(payroll.getSalary(3, 1, 2024));
//		payroll10.setPayId(13);
//		System.out.println(payroll.upPayroll(payroll10));
//        payroll.delPayroll(13);
	}

}
