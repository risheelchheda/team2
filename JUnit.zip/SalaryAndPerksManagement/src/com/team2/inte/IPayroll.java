
package com.team2.inte;

import java.util.List;

import com.team2.mod.Payroll;

/**
 * Interface that defines the operations related to payroll management.
 * Provides methods for retrieving, inserting, updating, and deleting payroll information.
 * Also includes methods for calculating salary and leave without pay (LWP).
 * 
 * @author Risheel
 */
public interface IPayroll {

    /**
     * Retrieves a list of all payroll records.
     *
     * @return A list of {@link Payroll} objects containing all payroll data.
     */
    public List<Payroll> retPayrolls();

    /**
     * Retrieves the payroll record for a specific payroll ID.
     *
     * @param pid The payroll ID for the record to retrieve.
     * @return A {@link Payroll} object containing the payroll details for the specified ID.
     */
    public Payroll retPayroll(int pid);

    /**
     * Retrieves the salary for an employee for a specific month and year.
     *
     * @param empId The employee ID for whom the salary is to be retrieved.
     * @param payMonth The month of the salary to retrieve (1-12).
     * @param payYear The year of the salary to retrieve.
     * @return A {@code double} representing the salary of the employee for the given month and year.
     */
    public double getSalary(int empId, int payMonth, int payYear);

    /**
     * Retrieves all salary data for a specific employee.
     *
     * @param empid The employee ID for whom the salary data is to be retrieved.
     * @return A list of lists containing salary details. Each sublist contains salary details for a specific period.
     */
    public List<List<Double>> getAllSalary(int empid);

    /**
     * Retrieves the Leave Without Pay (LWP) information for an employee for a specific month and year.
     *
     * @param empid The employee ID for whom the LWP data is to be retrieved.
     * @param payMonth The month of the LWP to retrieve (1-12).
     * @param payYear The year of the LWP to retrieve.
     * @return An {@code int} representing the number of leave without pay days for the employee.
     */
    public int getLWP(int empid, int payMonth, int payYear);

    /**
     * Inserts a new payroll record into the system.
     *
     * @param payroll The {@link Payroll} object containing the payroll information to insert.
     * @return A {@code String} indicating the success or failure of the operation.
     */
    public String insPayroll(Payroll payroll);

    /**
     * Updates an existing payroll record in the system.
     *
     * @param payroll The {@link Payroll} object containing the updated payroll information.
     * @return A {@code String} indicating the success or failure of the operation.
     */
    public String upPayroll(Payroll payroll);

    /**
     * Deletes a payroll record from the system based on the payroll ID.
     *
     * @param pid The payroll ID of the record to delete.
     * @return A {@code String} indicating the success or failure of the operation.
     */
    public String delPayroll(int pid);
}

