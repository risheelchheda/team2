package com.ris.hscls;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class HSCls {

	public static void main(String[] args) {
		HashMap<Integer,String> hs=new HashMap<>();
		int arr1[]= {1,2,3,4,5};
		String arr2[]= {"a","b","c","d","e"};
		for(int i=0;i<5;i++) {
			hs.put(arr1[i],arr2[i]);
		}
		System.out.println(hs);
		List arr3=Arrays.asList(hs.entrySet());
		for(Object a:arr3) {
			System.out.println(a);
		}
		
		Iterator itr=hs.entrySet().iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		Iterator itra=hs.keySet().iterator();
		while(itra.hasNext()) {
			Object key=itra.next();
			//hs.put(6, "f");     Do not modify a data structure inside a iterator it will throw error, use concurrent hash map to overcome this error
			System.out.println(key+"="+hs.get(key));
		}
		
	}

}
