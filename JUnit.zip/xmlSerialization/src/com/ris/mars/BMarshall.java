package com.ris.mars;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.ris.mods.Books;

public class BMarshall {

	
	/**
	 * Method which serializes java to xml
	 * @return
	 */
	
	public void retXmlBook() {
		JAXBContext context=null;
		try {
			context=JAXBContext.newInstance(Books.class);
			Marshaller marshal=context.createMarshaller();
			Books b=new Books(212,"Macbeth","Shakspeare");
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
			StringReader s=null;
			marshal.marshal(b,System.out);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

}
