package com.ris.cls;

import com.ris.mars.BMarshall;

public class MainCls {

	public static void main(String[] args) {
		BMarshall bm=new BMarshall();
		bm.retXmlBook();
	}

}
