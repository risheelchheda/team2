package com.ris.cls;

import java.util.Comparator;

public class Person implements Comparable<Person> {
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Person(int a,String b,String c) {
		this.id=a;
		this.name=b;
		this.email=c;
	}
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String name;
	private String email;
	@Override
	public int compareTo(Person o) {
		if(this.id==o.id) {
			return 0;
		}else if(this.id>o.id) {
			return 1;
		}else {
			return -1;
		}
	}
	
	@Override
	public String toString() {
		return this.id+" "+this.name+" "+this.email+"\n";
	}
}
	


