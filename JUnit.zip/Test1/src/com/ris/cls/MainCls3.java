package com.ris.cls;

//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainCls3 {
public static void main(String[] args) {
//	List<Person> p=new ArrayList<Person>();
//	String arr1[]= {"ram","shyam","tam","sam","bam"};
//	int arr2[]= {1000,70000,5000000,9000,400000};
//	for(int i=0;i<5;i++) {
//		Person e=new Person(arr2[i],arr1[i],arr1[i]+"@gmail.com");
//		p.add(e);
//	}
//	System.out.println("Before Sorting");
//	System.out.println(p);
//	System.out.println("*******************************************************************");
//	
////	Arrays.sort(p.toArray());
//	Collections.sort(p);
//	System.out.println(p);
	
	List<Person> lsp=new ArrayList<Person>();
	String arr1[]= {"Joyse","Charlie","James","Rita","Terry"};
	int[] arr2= {2,3,1,9,10};
	String arr3[]= {"Joyse@yahoo.com","Charlie@yahoo.com","James@yahoo.com","Rita@yahoo.com","Terry@yahoo.com"};
	for (int i = 0; i < arr3.length; i++) {
//		Employee emp=new Employee(arr1[i], arr2[i], arr3[i]);
//		ls.add(emp);
		Person per=new Person(arr2[i], arr1[i], arr3[i]);
		lsp.add(per);
	}
//	ls.sort(new Comparator<Employee>() {
//		@Override
//		public int compare(Employee o1, Employee o2) {
//			return o1.getSalary()-o2.getSalary();
//		}
//	});
	
	Collections.sort(lsp);
	System.out.println(lsp);
}
}
