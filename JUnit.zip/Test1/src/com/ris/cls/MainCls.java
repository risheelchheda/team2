package com.ris.cls;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainCls {
	public static void main(String[] args) {
		List<Student> students =new ArrayList<>();
		int arr1[]= {124,435,234,77,23};
		String arr2[]= {"Ram","Sham","Naam","Kaam","Ghaam"};
		for(int i=0;i<5;i++) {
			Student std=new Student();
			std.setSid(arr1[i]);
			std.setSname(arr2[i]);
			std.setSemail(arr2[i]+"@gmail.com");
			students.add(std);
		}
		System.out.println("Before Sorting");
		System.out.println(students);
		System.out.println("***********************************************************************");
		StudentSorter sor=new StudentSorter();
		Collections.sort(students,sor);
		System.out.println("After sorting");
		System.out.println(students);
		
		
		
		
	}
}
