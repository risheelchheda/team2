package com.ris.cls;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MainCls2 {

	public static void main(String[] args) {
		
		List<Employee> emp=new ArrayList<>();
		String arr1[]= {"ram","shyam","tam","sam","bam"};
		int arr2[]= {1000,70000,5000000,9000,400000};
		for(int i=0;i<5;i++) {
			Employee e=new Employee(arr1[i],arr2[i],arr1[i]+"@gmail.com");
			emp.add(e);
		}
		System.out.println("Before sorting");
		System.out.println(emp);
		System.out.println("*****************************************************************");
		
		emp.sort(new Comparator<Employee>(){
			public int compare(Employee o1,Employee o2) {
				return o1.getSalary()-o2.getSalary();
			}
		});
		System.out.println("Sorting on basis of salary");
		System.out.println(emp);
		System.out.println("*****************************************************************");
		
		emp.sort(new Comparator<Employee>(){
			public int compare(Employee o1,Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		System.out.println("Sorting on basis of name");
		System.out.println(emp);

	}

}
