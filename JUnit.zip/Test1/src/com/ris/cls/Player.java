package com.ris.cls;



public class Player{
	
	private int id;
	private String name;
	private int ranking;
	
	public Player() {
		// TODO Auto-generated constructor stub
	}
	public Player(int a,String b,int c) {
		// TODO Auto-generated constructor stub
		this.id=a;
		this.name=b;
		this.ranking=c;
	}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getRanking() {
		return ranking;
	}


	public void setRanking(int ranking) {
		this.ranking = ranking;
	}
	
	public String toString() {
		return this.id+" "+this.name+" "+this.ranking;
	}

}
