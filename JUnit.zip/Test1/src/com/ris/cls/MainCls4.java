package com.ris.cls;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class MainCls4 {
	public static void main(String[] args) {
		List<Player> pl=new ArrayList<>();
		int arr1[]= {52,58,23,9,12};
		String arr2[]= {"a","b","c","d","e"};
		int arr3[]= {323,43535,1313,887,1};
		
		for(int i=0;i<5;i++) {
			Player ply=new Player(arr1[i],arr2[i],arr3[i]);
			pl.add(ply);
		}
		
		System.out.println(pl);
		
		pl.sort(new Comparator<Player>() {
			public int compare(Player o1,Player o2) {
				return o1.getRanking()-o2.getRanking();
			}
		}
		);
		System.out.println(pl);
		
		try {
			ObjectMapper om=new ObjectMapper();
			String u=om.writeValueAsString(pl);
			System.out.println(u);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
