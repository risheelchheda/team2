package com.ris;

public class DCls extends CCls {
	public DCls() {
		// TODO Auto-generated constructor stub
		System.out.println("Constructor D");
	}

}
