package com.ris;

public interface IFaceB {
	
	public void methcc();
	public void methdd();

}
