package com.ris;

import java.util.Scanner;

public class MyClass {

	public static void main(String[] args) {
		//Class Introduction
		Person pObj=new Person();
		pObj.setPid(10);
		pObj.setPname("Risheel");
		pObj.setPemail("Risheel@gmail.com");
		System.out.println(pObj.getPid()+" "+pObj.getPname()+" "+pObj.getPemail());
		
		//Constructor initializer
		Books b=new Books("As you like it","Shakespear");
		
		//Inheritance
		GrandChild gch=new GrandChild();
		gch.methA();
		gch.methB();
		
		//Interface Implementation
		IFaceAImpl fa=new IFaceAImpl();
		fa.methAA();
		fa.methBB();
		fa.methcc();
		fa.methdd();
		
		//Abstract class implementation
		ChdBasCls cls=new ChdBasCls();
		cls.methEE();
		cls.methFF();
		
		//Constructor Chaining
		DCls clsa=new DCls();
		
		//Arrays in java
		int[] arr1=new int[3];
		arr1[0]=1;
		arr1[1]=2;
		arr1[2]=3;
		for (int i = 0; i < arr1.length; i++) {
			System.out.println("arr["+i+"]="+arr1[i]);
		}
		float[] arr2= {3.31f,5.53f,43.43f};
		int i=0;
		while (i<arr2.length) {
			System.out.println("arr["+i+"]="+arr2[i]);
			i++;
		}
		i=0;
		do {
			System.out.println("arr["+i+"]="+arr2[i]);
			i++;
		}while(i<arr2.length);
		String arr3[]= {"Ganesh","Ganapati","Vignaharta"};
		for(String a:arr3) {
			System.out.println(a);
		}
		boolean arr4[]= {true,false,true,false};
		for(boolean a:arr4) {
			if(a) {
				System.out.println("It is true");
			}
			else {
				System.out.println("It is false");
			}
		}
		
		//Taking inputs
		String name="";
		System.out.println("Enter your name");
		Scanner scan=new Scanner(System.in);
		name =scan.nextLine();
		System.out.printf("Your name is %s",name);
		
		
		

		
	}

}
