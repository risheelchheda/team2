package com.ris;

public class BCls extends ACls {
	
public BCls() {
	// TODO Auto-generated constructor stub
	System.out.println("Constructor B");
}
}
