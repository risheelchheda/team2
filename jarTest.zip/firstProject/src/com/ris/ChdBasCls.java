package com.ris;

public class ChdBasCls extends BasCls {

	@Override
	public void methEE() {
		// TODO Auto-generated method stub
		System.out.println("This is the fifth implementation method");
	}
	
}
