package com.ris;

public class ACls {
	public ACls() {
		// TODO Auto-generated constructor stub
		System.out.println("Constructor A");
	}
}
