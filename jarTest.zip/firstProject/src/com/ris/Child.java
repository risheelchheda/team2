package com.ris;

public class Child extends GrandPar {
	
	public void methB() {
		System.out.println("This is the child class");
	}
}
