package com.ris;

public abstract class BasCls {
	
	public abstract void methEE();
	
	public void methFF() {
		System.out.println("This is the sixth implementation method");
	}

}
