package com.ris;

public class CCls extends BCls {
	public CCls() {
		// TODO Auto-generated constructor stub
		System.out.println("Constructor C");
	}

}
