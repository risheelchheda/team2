package com.ris;

public class Books {
	
	private String bName;
	private String bAuth;
	
	public Books() {
		// TODO Auto-generated constructor stub
	}

	public Books(String a, String b) {
		this.bName=a;
		this.bAuth=b;
		System.out.println(this.bName+" by "+this.bAuth);
	}
}
