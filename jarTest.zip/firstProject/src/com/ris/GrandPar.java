package com.ris;

public class GrandPar {
	
	public void methA() {
		System.out.println("Hello I am grand parent");
	}

}
