package com.ris;

public class GrandChild extends Child {

}
