package com.ris;

public class IFaceAImpl implements IFaceA,IFaceB {

	@Override
	public void methAA() {
		// TODO Auto-generated method stu		
		System.out.println("This is the first implementation method ");

	}

	@Override
	public void methBB() {
		// TODO Auto-generated method stub
		System.out.println("This is the second implementation method");

	}

	@Override
	public void methcc() {
		// TODO Auto-generated method stub
		System.out.println("This is the third implementation method");
		
	}

	@Override
	public void methdd() {
		// TODO Auto-generated method stub
		System.out.println("This is the fourth implementation method");
		
	}
	


}
