package com.ris;

public interface IFaceA {
	public void methAA();
	public void methBB();

}
