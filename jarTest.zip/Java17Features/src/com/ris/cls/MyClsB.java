package com.ris.cls;

import java.awt.CardLayout;
import java.lang.classfile.instruction.NewMultiArrayInstruction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.w3c.dom.html.HTMLScriptElement;

public class MyClsB {
	
	public static void main(String[] args) {
		Integer[] arr1= {1,2,3,4,5,6,7,8};
		Function<Integer, Double> sqrtFun=(a)->Math.sqrt(a);
		System.out.println(sqrtFun.apply(21));
		
		BiFunction<Integer,Integer,Double> power=(a,b)->Math.pow(a,b);
		System.out.println(power.apply(12, 2));
		
		Function<String, String> retRevFunction=(a)->(new StringBuilder(a).reverse().toString());
		System.out.println(retRevFunction.apply("Risheel"));
		
		BiFunction<Integer, Integer, Double> retHypBiFunction=(a,b)->Math.hypot(a, b);
		System.out.println(retHypBiFunction.apply(13, 89));
		
		Function<Integer, Double> funaFunction=(a)->Math.sqrt(a);
		Function<Double,Double> funb=(a)->Math.log(a);
		
		//Calling a function after another function
		var fund=funaFunction.andThen(funb);
		System.out.println(fund.apply(2));
		
		Function<Integer, Double> fune=(a)->Math.pow(a, 2);
		Function<Double,Double> funf=(a)->Math.log(a);
		var myVar=funf.compose(fune);
		System.out.println(myVar.apply(8));
		
		Predicate<Integer> pred=(a)->a>10;
		System.err.println(pred.test(89));
		
		Predicate<String> preda=(a)->a=="";
		System.out.println(preda.test(""));
		
		String[] arr= {"a","b","c","d","e","f","g",""};
		Arrays.asList(arr).stream().filter(n->n!="").forEach(System.out::println);
		
		Predicate<Integer> dPredicate=a->a<10;
		Predicate<Integer> ePred=a->a<20;
		var fPred=dPredicate.and(ePred);
		System.out.println(fPred.test(8));
		
		System.out.println(fPred.negate().test(5));
		
		List<String> lsa=new ArrayList<String>();
		List<String> lsb=new ArrayList<String>();
		lsa.add("a");
		lsa.add("b");
		lsa.add("c");
		lsa.add("d");
		lsa.add("e");
		
		lsb.add("s");
		lsb.add("d");
		lsb.add("f");
		lsb.add("g");
		lsb.add("h");
		
		BiConsumer<List<Integer>, Set<Integer>> aConsumer=(list1,set2)->{
			Set<Integer> set3=list1.stream().collect(Collectors.toSet());
			Iterator<Integer> irta=set2.iterator();
			Iterator<Integer>irtb=set3.iterator();
			while(irta.hasNext()) {
				System.out.println(irta.next());
			}
			while(irtb.hasNext()) {
				System.out.println(irtb.next());
			}
		};
		
		List<Integer> laaIntegers=new ArrayList<Integer>();
		Arrays.asList(21,21,21,12,12,12,21).forEach(n->laaIntegers.add(n));
		Set<Integer> setaaIntegers=new HashSet<Integer>();
		Arrays.asList(32,32,322,32,32,32,23,32,32,32,32).forEach(n->setaaIntegers.add(n));
		aConsumer.accept(laaIntegers, setaaIntegers);
		
		
		varyingArgs(1,2,3,4,5,6,7,8,9,10);
		varyingArgs(23,4);
		
		
		
		List<Integer>list=Stream.iterate(1, e->e+1).filter(a->a%2==0).limit(20).collect(Collectors.toList());
		System.out.println(list);
		
		
		Integer[] arr9= {11,12,13,14,15,16};
		String[] arr10= {"Stringa","Stringb","Stringc","Stringd","Stringe","Stringf"};
		int k=0;
		List<Cubicle> cubL=new ArrayList<Cubicle>();
		Arrays.asList(arr9).stream().forEach(n->{
			for(String a:arr10) {
				cubL.add(new Cubicle(n,a));
			}
		});
		System.err.println(cubL);
				
		Arrays.asList(arr).parallelStream().filter(n->n!="").forEach(System.out::println);
		
		
		}
	
	
	
	
	
	//Taking variable argument

	public static void varyingArgs(Integer ...a) {
		Arrays.asList(a).forEach(System.out::println);
	}
}


