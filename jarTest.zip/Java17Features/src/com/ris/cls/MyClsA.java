package com.ris.cls;

import java.awt.geom.Line2D;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyClsA{
	
	static String saySomething(){
		return "This is a say something method";
	}
	
	
	
	public static void main(String[] args) {
		// This is method reference
		IFaceBasA bas=MyClsA::saySomething;
		System.out.println(bas.mySpeech());
		Integer[] arr= {1,2,3,4,5,6,7,8,9,10};
		Arrays.asList(arr).stream().forEach(n->System.out.println(n));
		System.out.println("_".repeat(127));
		Arrays.asList(arr).stream().filter(n-> n%2==0).forEach(n->System.out.println(n));
		System.out.println("_".repeat(127));
		Boolean arr1[]= {true,false,true,true,true,false,false,false};
		Arrays.asList(arr1).stream().filter(n->n).forEach(n->System.out.println(n));
		System.out.println("_".repeat(127));
		Character arr2[]= {'a','q','w','e','r','t','y','u','i','o','p'};
		Arrays.asList(arr2).stream().filter(n->n=='a' || n=='e'||n=='i'||n=='o'||n=='u').forEach(System.out::println);
		System.out.println("_".repeat(127));

		List<Cubicle> cList=new ArrayList<Cubicle>();
		Integer[] arr3= {11,12,13,14};
		String[] arr4= {"East","West","South","North"};
		for(int i=0;i<4;i++) {
			Cubicle cubicle=new Cubicle(arr3[i],arr4[i]);
			cList.add(cubicle);
		}
		System.out.println("_".repeat(127));

//		cList.stream().forEach(n->System.out.println("Did "+ n.getDim()+" Dname "+n.getName()));
		cList.stream().forEach(System.out::println);	
		System.out.println("_".repeat(127));

		cList.stream().filter(n->n.getDim()%2==0).forEach(System.out::println);
		System.out.println("_".repeat(127));
		
	}

}
