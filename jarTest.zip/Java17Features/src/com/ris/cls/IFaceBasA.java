package com.ris.cls;


@FunctionalInterface
public interface IFaceBasA {
	String mySpeech();
}
