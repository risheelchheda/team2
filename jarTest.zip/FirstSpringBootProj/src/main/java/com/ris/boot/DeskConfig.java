package com.ris.boot;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DeskConfig {
	@Bean
	public Desktops retDesk() {
		Desktops ds=new Desktops(21,"inspiron","dell");
		return ds;
	}
}
