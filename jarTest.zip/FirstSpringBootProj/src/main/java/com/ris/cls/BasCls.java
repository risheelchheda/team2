package com.ris.cls;

public abstract class BasCls {
	public abstract String retRoot(int a);

	private String emailId;
	private String mobile;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
}
