package com.ris.cls;

import java.util.Arrays;
import java.util.List;

public class University {
	private String uname;
	private Student[] sList;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public Student[] getsList() {
		return sList;
	}

	public void setsList(Student[] sList) {
		this.sList = sList;
	}

	@Override
	public String toString() {
		return "University [uname=" + uname + ", sList=" + Arrays.toString(sList) + "]";
	}

}
