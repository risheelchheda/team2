package com.ris.cls;

public interface IFaceA {

	default String retStr(String a) {
		return a.toUpperCase();
	}
	public String retStra();
	public double retDouble();
}
