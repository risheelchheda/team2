package com.ris.cls;

import java.util.List;

public class Department {
	private int deptid;
	private String deptname;
	private List<Professor> lprofs;
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public List<Professor> getLprofs() {
		return lprofs;
	}
	public void setLprofs(List<Professor> lprofs) {
		this.lprofs = lprofs;
	}
	@Override
	public String toString() {
		return "Department [deptid=" + deptid + ", deptname=" + deptname + ", lprofs=" + lprofs + "]";
	}
	
}
