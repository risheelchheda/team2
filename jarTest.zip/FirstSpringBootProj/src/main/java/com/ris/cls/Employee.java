package com.ris.cls;

public class Employee extends Person {
	private String organization;

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	@Override
	public String toString() {
		return "Employee [organization=" + organization + "]";
	}

}
