package com.ris.cls;

public class Manager extends Employee{
	private int manId;

	public int getManId() {
		return manId;
	}

	public void setManId(int manId) {
		this.manId = manId;
	}
	
}
