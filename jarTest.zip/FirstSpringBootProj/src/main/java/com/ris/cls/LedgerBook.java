package com.ris.cls;

public class LedgerBook {
	private int leId;
	private String leItem;
	private int quantity;
	private String leCat;
	public LedgerBook() {
		// TODO Auto-generated constructor stub
	}
	public LedgerBook(String item,int quant) {
		// TODO Auto-generated constructor stub
		this.leItem=item;
		this.quantity=quant;
	}
	public int getLeId() {
		return leId;
	}
	public void setLeId(int leId) {
		this.leId = leId;
	}
	public String getLeCat() {
		return leCat;
	}
	public void setLeCat(String leCat) {
		this.leCat = leCat;
	}
	
	@Override
	public String toString() {
		return "LedgerBook [leId=" + leId + ", leItem=" + leItem + ", quantity=" + quantity + ", leCat=" + leCat + "]";
	}
	
	
}
