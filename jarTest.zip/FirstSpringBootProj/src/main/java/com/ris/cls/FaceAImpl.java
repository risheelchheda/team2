package com.ris.cls;

public class FaceAImpl implements IFaceA {

	@Override
	public String retStra() {
		// TODO Auto-generated method stub
		return "From child class";
	}

	@Override
	public double retDouble() {
		// TODO Auto-generated method stub
		return Math.PI;
	}

}
