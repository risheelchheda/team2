package com.ris.cls;


public class BankAccount {
	private String bankid;
	private String bankName;
	private String actName;
	public BankAccount() {
		// TODO Auto-generated constructor stub
	}
	
	public BankAccount(String id,String name,String act) {
		// TODO Auto-generated constructor stub
		this.bankid=id;
		this.bankName=name;
		this.actName=act;
	}
	@Override
	public String toString() {
		return "BankAccount [bankid=" + bankid + ", bankName=" + bankName + ", actName=" + actName + "]";
	}
	
	
}
