package com.ris.cls;

public class Professor {
	private String pname;
	private String pbranch;
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPbranch() {
		return pbranch;
	}
	public void setPbranch(String pbranch) {
		this.pbranch = pbranch;
	}
	@Override
	public String toString() {
		return "Professor [pname=" + pname + ", pbranch=" + pbranch + "]";
	}
	
	
}
