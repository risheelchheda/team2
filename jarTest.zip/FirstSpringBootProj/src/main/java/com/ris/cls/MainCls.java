package com.ris.cls;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainCls {
	public static void main(String[] args) {
		ApplicationContext cont = new ClassPathXmlApplicationContext("applicationContext.xml");
		Books b = (Books) cont.getBean("booka");
		System.out.println(b.getBid() + " " + b.getBname() + " " + b.getBauth());

		BankAccount bact = (BankAccount) cont.getBean("bact");
		System.out.println(bact);

		LedgerBook ledgerBook = (LedgerBook) cont.getBean("Ledgehome");
		System.out.println(ledgerBook);

		Employee employee = (Employee) cont.getBean("empbean");
		System.out.println("id=" + employee.getPid() + " name=" + employee.getPname() + " email=" + employee.getPemail()
				+ " organization=" + employee.getOrganization());
		
		Manager manager=(Manager)cont.getBean("manager");
		System.out.println("id="+manager.getPid()+" name="+manager.getPname()+" email="+manager.getPemail()+" organization="+manager.getOrganization()+" managerId="+manager.getManId());

		ChdCls chdCls=(ChdCls)cont.getBean("chd");
		System.out.println("email="+chdCls.getEmailId()+" mobile"+chdCls.getMobile()+" root="+chdCls.retRoot(10000));
		
		FaceAImpl f=(FaceAImpl)cont.getBean(FaceAImpl.class);
		System.out.println(f.retStr("Risheel")+" "+f.retStra()+" "+f.retDouble());
		
		University uni=(University)cont.getBean("uni");
		System.out.println(uni);
//		Arrays.asList(uni.getsList()).stream().forEach(new Consumer<Student>(){
//			public void accept(Student st) {
//				System.out.println(st);
//			}
//		});
		
		Arrays.asList(uni.getsList()).stream().forEach(n->{
			System.out.println(n);
		});
		
		Department dept=(Department)cont.getBean("depta");
		dept.getLprofs().stream().forEach(p->{
			System.out.println(p);
		});
		
		FirstCls fir=(FirstCls)cont.getBean("fir");
		System.out.println(fir.getIdenStr());
		Iterator<Map.Entry<Integer, String>> iterator = fir.getMyMap().entrySet().iterator();
		iterator.forEachRemaining(entry -> 
		    System.out.println("Key: " + entry.getKey() + " Value: " + entry.getValue())
		);
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		fir.getMyMap().entrySet().forEach(entry->System.out.println("Key:"+entry.getKey()+" "+"Value:"+entry.getValue()));
	}
}
