package com.ris.cls;

public class ChdCls extends BasCls {

	@Override
	public String retRoot(int a) {
		return "Root is "+Math.sqrt(a);
	}

}
