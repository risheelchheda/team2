package a.b.c;

public class MyClass {
public static void main(String[] args) {
	MainCls cls =new MainCls();
	String u=cls.retRev("Risheel");
	System.out.println(u);
	System.out.println(cls.retRoot(10));
}
}
