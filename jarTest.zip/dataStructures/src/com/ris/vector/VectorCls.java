package com.ris.vector;

import java.awt.FlowLayout;
import java.util.Vector;

public class VectorCls {

	public static void main(String[] args) {

		Vector vec = new Vector();
		for (int i = 0; i < 1001; i++) {
			String j = "Sqrt(" + i + ")=" + Math.sqrt(i);
			vec.add(j);
		}
		System.out.println(vec);

		for (Object a : vec) {
			System.out.println(a);
		}
		
		
		//GUI
		MainFrm frm=new MainFrm();
		frm.setDefaultCloseOperation(2);
		frm.setVisible(true);
		frm.setLayout(new FlowLayout());
		frm.setSize(1000,1000);
	}

}
