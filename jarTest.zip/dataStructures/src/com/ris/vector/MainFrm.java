package com.ris.vector;

import java.awt.Container;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class MainFrm extends JFrame {
	
	public MainFrm() {
	
	Container cont=getContentPane();
	Vector vec= new Vector();
	for(int i=0;i<1001;i++) {
		vec.add("Log("+i+")="+Math.log(i));
	}
	JComboBox box =new JComboBox(vec);
	cont.add(box);
	}
}
