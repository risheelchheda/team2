package com.ris.hashtablr;

import java.util.Hashtable;

public class HashTbl {
	
	public static void main(String[] args) {
		int[] arr1= {1,2,3,4,5};
		String[] arr2= {"a","b","c","d","e"};
		Hashtable<Integer,String> hs=new Hashtable<>();
		for(int i=0;i<arr2.length;i++) {
			hs.put(arr1[i],arr2[i]);
		}
		System.out.println(hs);
	}

}
