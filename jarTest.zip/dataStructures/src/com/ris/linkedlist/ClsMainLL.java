package com.ris.linkedlist;

import java.util.LinkedList;

public class ClsMainLL {
	
	public static void main(String[] args) {
		LinkedList<String> ll=new LinkedList<>();
		LinkedList<String> ll1=new LinkedList<>();
		LinkedList<String> ll2=new LinkedList<>();
		String arr[]= {"a","b","c","d","e","f"};
		for(String j:arr) {
			ll.addFirst(j);//Like a stack
			ll1.addLast(j);//Like a queue
			ll2.add(j);//Like an arrayList
		}
		System.out.println(ll);
		System.out.println(ll1);
		System.out.println(ll2);
		int size=ll.size();//to find size of linked list
		System.out.println(size);
		System.out.println(ll.get(2)); //get a particular element
		
		
		//Primitive datatypes in linked list
		LinkedList<Integer> llint=new LinkedList<>();
		for(int i=0;i<1001;i++) {
			llint.add(i);
		}
		System.out.println(llint);
		
		LinkedList<Character> llchar=new LinkedList<>();
		for(int i=0;i<26;i++) {
			llchar.add((char) (i+97));
		}
		System.out.println(llchar);
		
		LinkedList<Boolean> llbool=new LinkedList<>();
		for(int i=0;i<1000;i++) {
			if(i%2==0) {
				llbool.add(true);
			}
			else {
				llbool.add(false);
			}
		}
		System.out.println(llbool);
	}

}
