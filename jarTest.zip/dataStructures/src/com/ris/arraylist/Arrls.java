package com.ris.arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class Arrls {

	public static void main(String[] args) {
		
		ArrayList al=new ArrayList();
		for(int i=0;i<1001;i++) {
			al.add("Sqrt("+i+")="+Math.sqrt(i));
		}
		System.out.println(al);
		
		for(Object l:al) {
			System.out.println(l);
		}
		
		
		
		//Getting inputs when the number of inputs are not known
		
		
	}
}
