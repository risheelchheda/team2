package com.ris.arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrAppCls {

	public static void main(String[] args) {
		
		ArrayList al=new ArrayList();
		Scanner scan=new Scanner(System.in);
		String ans="y";
		int i=1;
		while(ans.equalsIgnoreCase("y")) {
			System.out.println("Running the loop for "+i);
			al.add(i);
			i++;
			System.out.println("Enter y to continue");
			ans=scan.nextLine();
		}
		System.out.println("The final count is "+(i-1));
		for(Object obj:al) {
			System.out.println(obj);
		}
		
		//CASESTUDY
		
		ArrayList arr=new ArrayList();
		ans="y";
		while(ans.equalsIgnoreCase("y")) {
			System.out.println("Enter your string");
			String str=scan.nextLine();
			arr.add(str);
			System.out.println("Enter y to continue");
			ans=scan.nextLine();
		}
		for(Object o:arr) {
			StringBuffer stb=new StringBuffer();
			String temp=o.toString();
			stb.append(temp);
			stb.reverse();
			System.out.println(stb);
		}
		
		
	}
	
}
