package com.ris.hashset;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class HashSetCls {
	
	public static void main(String[] args) {
		
		//Same syntax for linkedHashSet
		
		int[] arr= {1,1,1,1,11,4,4,4,5,5,5,5,7,7,7,7,7};
		HashSet hset=new HashSet(); 
		LinkedHashSet lsh1=new LinkedHashSet();
		for(int i:arr) {
			hset.add(i);
			lsh1.add(i);
		}
		System.out.println(hset);
		System.out.println(lsh1);
		
		
		
		char[] charr= {'a','a','a','a','b','b','b','b'};
		LinkedHashSet lsh=new LinkedHashSet();
		HashSet chset=new HashSet();
		for(char i:charr) {
			lsh.add(i);
			chset.add(i);
		}
		System.out.println(lsh);
		System.out.println(chset);
		
		
		
		//TreeSet
		char[] arr2= {'z','g','t','p','q','g','a','b'};
		int[] arr1= {23,4,5,63,2,6,4,3,6,23,6,3,43,7,8,9};
		TreeSet ts=new TreeSet();
		TreeSet ts1=new TreeSet();
		for(int i:arr1) {
			ts.add(i);
		}
		System.out.println(ts);
		for(char i:arr2) {
			ts1.add(i);
		}
		System.out.println(ts1);
	}

}
