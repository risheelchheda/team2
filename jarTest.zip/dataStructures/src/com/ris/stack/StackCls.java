package com.ris.stack;

import java.util.Scanner;
import java.util.Stack;

public class StackCls {
	public static void main(String[] args) {
		
		//Basic implementation of stack
		Stack sta =new Stack();
		String[] arr= {"a","b","c","d","e"};
		for(String j:arr) {
			sta.push(j);
		}
		while(!(sta.isEmpty())) {
			System.out.println(sta.pop());
		}
		
		
		Scanner scan=new Scanner(System.in);
		
		//Reversing a string using stack
		System.out.println("Enter the string to be reversed");
		String str=scan.nextLine();
		char[] ar=str.toCharArray();
		for(char a:ar) {
			sta.push(a);
		}
		while(!(sta.isEmpty())) {
			System.out.print(sta.pop());
		}
		
		
		System.out.println("Enter your name");
		String name=scan.nextLine();
		char[] arr1=name.toCharArray();
		Stack stk1=new Stack();
		for(char k:arr1) {
			stk1.push(k);
		}
		while(!(stk1.isEmpty())){
			System.out.print(stk1.pop());
		}
		
	}
	
}
