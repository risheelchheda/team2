package com.ris.clsa;

import java.awt.image.AreaAveragingScaleFilter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

public class MnCls {
	public static void main(String[] args) throws JAXBException {
		File f = new File("C:\\Users\\localadmin\\Desktop\\JavaTraining\\NPCIFolder\\bookshelf.xml");
		JAXBContext context = JAXBContext.newInstance(BookShelf.class);
		Marshaller mar = context.createMarshaller();
		int a[] = { 1, 2, 3, 4, 5 };
		String[] b = { "The Great Adventure", "Java Programming 101", "The Secrets of the Universe", "Learning Python","Mastering Algorithms" };
		String[] c = { "John Doe", "Jane Smith", "Alice Johnson", "Robert Brown", "Mary Clark" };
		List<Books> lb=new ArrayList<Books>();
		for(int i=0;i<5;i++) {
			Books books=new Books(a[i],b[i],c[i]);
			lb.add(books);
		}
		BookShelf bookShelf=new BookShelf("Home",lb);
		mar.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		mar.marshal(bookShelf, f);
	}
}
