package com.ris.clsa;

import java.io.Serializable;
import java.util.List;

import javax.lang.model.element.NestingKind;

import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "bookshelf")
@XmlType(propOrder = {"shelfID","lBooks"})
public class BookShelf implements Serializable {

	private String shelfID;
	private List<Books> lBooks;

	public BookShelf() {

	}

	public BookShelf(String id,List<Books> lr) {
		this.shelfID=id;
		this.lBooks=lr;
	}

	public String getShelfID() {
		return shelfID;
	}

	public void setShelfID(String shelfID) {
		this.shelfID = shelfID;
	}

	public List<Books> getlBooks() {
		return lBooks;
	}

	public void setlBooks(List<Books> lBooks) {
		this.lBooks = lBooks;
	}

}
