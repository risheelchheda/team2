package com.ris.cls;

import java.io.StringReader;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

public class Deserializing {

	public static void main(String[] args) throws JAXBException {
		
		String xml="<person>\r\n<email>@yahoo.com</email>\r\n<id>2</id>\r\n<name>Risheela</name>\r\n</person>\r\n";
		JAXBContext context=JAXBContext.newInstance(Person.class);
		Unmarshaller um=context.createUnmarshaller();
		Person p=(Person)um.unmarshal(new StringReader(xml));
		System.out.println("id: "+p.getId()+"\nname: "+p.getName()+"\nemail: "+p.getName()+p.getEmail());

		
		String xml1="<books>\r\n<auth>Shakespeare</auth>\r\n<id>1</id>\r\n<name>Macbeth</name>\r\n</books>";
		JAXBContext context1=JAXBContext.newInstance(Books.class);
		Unmarshaller umm=context1.createUnmarshaller();
		Books b=(Books)umm.unmarshal(new StringReader(xml1));
		System.out.println("id: "+b.getId()+"\nname: "+b.getName()+"\nemail: "+b.getAuth());
	}

}
