package com.ris.cls;


import java.io.File;
import java.io.FileOutputStream;
import java.rmi.MarshalException;
import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

public class XmlTester {

	public static void main(String[] args) throws JAXBException {
		String paths = "C:\\Users\\localadmin\\Desktop\\JavaTraining\\NPCIFolder\\laptops.xml";
		JAXBContext context = JAXBContext.newInstance(Laptops.class);
		Marshaller mar = context.createMarshaller();
		int arr1[] = { 1, 2, 3, 4, 5 };
		String[] arr2 = { "XPS 13", "MacBook Pro", "ThinkPad X1 Carbon", "Spectre x360", "Surface Laptop 5" };

		String[] arr3 = { "Dell", "Apple", "Lenovo", "HP", "Microsoft" };
		List<Laptops> ll=new ArrayList<>();
		for(int i=0;i<5;i++) {
			Laptops l=new Laptops();
			l.setManid(arr1[i]);
			l.setLname(arr2[i]);
			l.setLbrand(arr3[i]);
			ll.add(l);
		}
		mar.marshal(ll.get(0), new File(paths));
		System.out.println("Done");
	}

}
