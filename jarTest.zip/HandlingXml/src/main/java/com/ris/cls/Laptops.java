package com.ris.cls;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@XmlRootElement(name="laptops")
public class Laptops implements Serializable{

	private int manid;
	private String lname;
	private String lbrand;
	public int getManid() {
		return manid;
	}
	public void setManid(int manid) {
		this.manid = manid;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLbrand() {
		return lbrand;
	}
	public void setLbrand(String lbrand) {
		this.lbrand = lbrand;
	}
	
}
