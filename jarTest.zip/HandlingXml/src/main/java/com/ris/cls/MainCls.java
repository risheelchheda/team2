package com.ris.cls;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

public class MainCls {
	
	
	public static void main(String[] args) throws JAXBException {
		JAXBContext context=JAXBContext.newInstance(Person.class);
		Marshaller mar=context.createMarshaller();
		Person p=new Person();
		p.setName("Risheel");
		p.setId(1);
		p.setEmail("@gmail.com");
		mar.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		mar.marshal(p, System.out);
		
		JAXBContext context1=JAXBContext.newInstance(Books.class);
		Marshaller mar1=context1.createMarshaller();
		Books b=new Books();
		b.setId(1);
		b.setName("Macbeth");
		b.setAuth("Shakespeare");
		mar1.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		mar1.marshal(b, System.out);
	}

}
