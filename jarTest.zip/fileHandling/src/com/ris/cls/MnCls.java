package com.ris.cls;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MnCls implements IFaceConsts {

	public static void main(String[] args) throws IOException {
		readingFilesNames();
		String fname="sqrt.txt";
		String op="";
		FileInputStream f=new FileInputStream(new File(paths+fname));
		int y=0;
		while((y=f.read())!=-1) {
			op+=(char)y;
		}
		System.out.println(op);
		f.close();
	}

	private static void writingFiles() throws FileNotFoundException, IOException {
		String fname="sqrt.txt";
		String fin="";
		for(int i=1;i<1001;i++) {
			fin+="Sqrt("+i+")="+Math.sqrt(i)+";"+System.lineSeparator();	
		}
		File file=new File(paths+fname);
		FileOutputStream fos=new FileOutputStream(file);
		fos.write(fin.getBytes());
		fos.flush();
		fos.close();
		System.out.println("Done Writing");
	}

	private static void readingFilesNames() {
		File ff=new File(paths);
		String arr[]=ff.list();
		for(String j:arr) {
			if(j.indexOf(".txt")>0) {
				System.out.println(j);
			}
		}
	}

	private static void deleteDirectory() {
		String dNamea="MyDirTest1";
		File f=new File(paths+dNamea);
		f.delete();
	}

	private static void renameDirectory() {
		String dName="MyDirTest";
		String dNamea="MyDirTest1";
		File f=new File(paths+dName);
		f.renameTo(new File(paths+dNamea));
	}
	
	/**
	 * Stub to create a new directory in the path mentioned in the interface
	 * @author localadmin
	 */

	private static void createDirectory() {
		String dName="MyDirTest";
		File f=new File(paths+dName);
		f.mkdir();
	}

	/**
	 * Method to create a new file in the directory mentioned in the interface should only be executed once
	 * @author localadmin
	 */
	private static void createFile() {
		String myFile="Tester.txt";
		System.out.println(paths);
		File file=new File(paths+myFile);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
