package com.ris.cls;

@MyAnnoClass(retDesc="Bank Account Class",retPrior = 90)
public class BankAccount {

	private int bid;
	private String bname;
	private String ahname;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAhname() {
		return ahname;
	}
	public void setAhname(String ahname) {
		this.ahname = ahname;
	}
	
	
}
