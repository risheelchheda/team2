package com.ris.cls;

public class Person {
	@MyAnnoField(descField = "Adhaar Number")
	private int pid;
	@MyAnnoField(descField = "Name of Person")
	private String pname;
	@MyAnnoField(descField = "Email of Person")
	private String pemail;
	@MyAnnoField(descField = "Phone Number of the Person")
	private String pmobile;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	public String getPmobile() {
		return pmobile;
	}
	public void setPmobile(String pmobile) {
		this.pmobile = pmobile;
	}
	
}
