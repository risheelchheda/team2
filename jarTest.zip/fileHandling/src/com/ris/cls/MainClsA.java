package com.ris.cls;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class MainClsA {
	public static void main(String[] args) {
		BankAccount ba = new BankAccount();
		MyAnnoClass ma=ba.getClass().getAnnotation(MyAnnoClass.class);
		System.out.println(ma.retDesc());
		System.out.println(ma.retPrior());
		
		Person p=new Person();
		for(Field field:p.getClass().getDeclaredFields()) {
			MyAnnoField af=(MyAnnoField)field.getAnnotation(MyAnnoField.class);
			String fin=String.format("Field: %s\nAnnotation value: %s\n",field.getName(),af.descField());
			System.out.println(fin);
			
		Books b=new Books();
		for(Method m:b.getClass().getDeclaredMethods()){
			MyAnnoMeth am=(MyAnnoMeth)m.getAnnotation(MyAnnoMeth.class);
			String f=String.format("Method: %s\nVlaue: %s\n", m.getName(),am.descMeth());
			System.out.println(f);
		}
		}

	}
}
