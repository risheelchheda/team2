package com.ris.cls;

public interface IFaceConsts {
	public static final String paths="C:\\Users\\localadmin\\Desktop\\JavaTraining\\NPCIFolder\\";
}	
