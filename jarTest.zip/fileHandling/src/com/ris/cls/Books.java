package com.ris.cls;

@MyAnnoClass(retDesc = "This class contains the information about the books in a library")
public class Books {
	private int bookid;
	private String bname;
	private String bauth;
	
	@MyAnnoMeth(descMeth = "This method describes the library")
	public String retDets() {
		return "This is a class describing a library";
	}
	@MyAnnoMeth(descMeth = "This method returns the first book in the library")
	public String retBookFirst() {
		return "Macbeth";
	}
}
