package com.ris.cls;

public class MainCls {

	public static void main(String[] args) {
		//Using anonymous classes in interface
		IFaceA faceA=new IFaceA() {
			@Override
			public String retRvStr(String a) {
				StringBuilder strb=new StringBuilder();
				strb.append(a);
				strb.reverse();
				return strb.toString();
				}
			@Override
			public String retUpStr(String a) {
				// TODO Auto-generated method stub
				return a.toUpperCase();
			}
		};
		
		System.out.println(faceA.retRvStr("Risheel"));
		System.out.println(faceA.retUpStr("Risheel"));
		
		
		//Using anonymous class in abstract class
		BasCls bas=new BasCls() {
			@Override
			public String retRevStr(String a) {
				StringBuilder strb=new StringBuilder();
				strb.append(a);
				strb.reverse();
				return strb.toString();
			}
		};
		bas.retA();//You can call non abstract methods also in this anonymous class
		bas.retB();
		System.out.println(bas.retRevStr("Risheel"));
		
		
	}

}
