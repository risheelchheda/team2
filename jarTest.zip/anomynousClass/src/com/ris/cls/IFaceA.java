package com.ris.cls;

public interface IFaceA {
	
	public String retRvStr(String a);
	public String retUpStr(String a);

}
