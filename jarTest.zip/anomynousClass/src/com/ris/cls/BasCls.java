package com.ris.cls;

public abstract class BasCls {
	public abstract String retRevStr(String a);
	public void retA() {
		System.out.println("First Non Abstract method");
	}
	public void retB() {
		System.out.println("Second Non Abstract method");
	}
}
